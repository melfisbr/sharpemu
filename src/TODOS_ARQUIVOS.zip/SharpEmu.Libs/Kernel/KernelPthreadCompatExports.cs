// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using System.Collections.Concurrent;
using System.Threading;
using SharpEmu.HLE;

namespace SharpEmu.Libs.Kernel;

public static partial class KernelPthreadCompatExports
{
    internal static readonly ConcurrentDictionary<ulong, PthreadMutexState> _mutexStates = new();
    internal static readonly ConcurrentDictionary<ulong, PthreadCondState> _condStates = new();

    private static long _nextMutexWakeId;
    private static long _nextCondWakeId;

    [SysAbiExport(
        Nid = "EotR8a3ASf4",
        ExportName = "pthread_self",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadSelf(CpuContext ctx)
    {
        ctx[CpuRegister.Rax] = KernelPthreadState.GetCurrentThreadHandle();
        return 0;
    }

    [SysAbiExport(
        Nid = "7Xl257M4VNI",
        ExportName = "pthread_equal",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadEqual(CpuContext ctx)
    {
        ctx[CpuRegister.Rax] =
            ctx[CpuRegister.Rdi] == ctx[CpuRegister.Rsi] ? 1UL : 0UL;
        return 0;
    }

    [SysAbiExport(
        Nid = "aI+OeCz8xrQ",
        ExportName = "scePthreadSelf",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadSelf(CpuContext ctx) => PthreadSelf(ctx);

    internal sealed class PthreadMutexState
    {
        public object SyncRoot { get; } = new();

        public string WakeKey { get; } =
            "pthread_mutex#" +
            Interlocked.Increment(ref _nextMutexWakeId).ToString("X");

        public ulong OwnerThreadId { get; set; }
        public int RecursionCount { get; set; }

        public bool TryAcquireUncontended(ulong threadId)
        {
            if (OwnerThreadId != 0)
            {
                return false;
            }

            OwnerThreadId = threadId;
            RecursionCount = 1;
            return true;
        }

        public void IncrementRecursion() => RecursionCount++;

        public void DecrementRecursion()
        {
            if (RecursionCount > 0)
            {
                RecursionCount--;
            }
        }
    }

    internal sealed class PthreadCondState
    {
        public object SyncRoot { get; } = new();

        public string WakeKey { get; } =
            "pthread_cond#" +
            Interlocked.Increment(ref _nextCondWakeId).ToString("X");

        public int Waiters { get; set; }
    }

    private sealed class MutexBlockWaiter : IGuestThreadBlockWaiter
    {
        public required PthreadMutexState State { get; init; }
        public required ulong ThreadId { get; init; }

        public int Resume() => (int)OrbisGen2Result.ORBIS_GEN2_OK;

        public bool TryWake()
        {
            lock (State.SyncRoot)
            {
                if (State.OwnerThreadId == ThreadId)
                {
                    return true;
                }

                return State.TryAcquireUncontended(ThreadId);
            }
        }
    }

    [SysAbiExport(
        Nid = "7H0iTOciTLo",
        ExportName = "pthread_mutex_lock",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadMutexLock(CpuContext ctx)
    {
        var mutexAddress = ResolveMutexAddress(ctx, ctx[CpuRegister.Rdi]);
        if (mutexAddress == 0)
        {
            return SetResult(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        var state = _mutexStates.GetOrAdd(
            mutexAddress,
            static _ => new PthreadMutexState());

        var threadId = KernelPthreadState.GetCurrentThreadHandle();

        lock (state.SyncRoot)
        {
            if (state.OwnerThreadId == threadId)
            {
                state.IncrementRecursion();
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }

            if (state.TryAcquireUncontended(threadId))
            {
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }
        }

        // Never block a native host worker with Monitor.Wait. Capture the
        // import continuation and let the guest scheduler park this guest
        // thread until unlock makes the mutex available.
        if (GuestThreadExecution.IsGuestThread &&
            GuestThreadExecution.TryGetCurrentImportCallFrame(out _) &&
            GuestThreadExecution.RequestCurrentThreadBlock(
                ctx,
                "pthread_mutex_lock",
                state.WakeKey,
                new MutexBlockWaiter
                {
                    State = state,
                    ThreadId = threadId,
                }))
        {
            return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
        }

        // A non-guest caller cannot be cooperatively parked.
        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_BUSY);
    }

    [SysAbiExport(
        Nid = "K-jXhbt2gn4",
        ExportName = "pthread_mutex_trylock",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadMutexTrylock(CpuContext ctx)
    {
        var mutexAddress = ResolveMutexAddress(ctx, ctx[CpuRegister.Rdi]);
        if (mutexAddress == 0)
        {
            return SetResult(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        var state = _mutexStates.GetOrAdd(
            mutexAddress,
            static _ => new PthreadMutexState());

        var threadId = KernelPthreadState.GetCurrentThreadHandle();

        lock (state.SyncRoot)
        {
            if (state.OwnerThreadId == threadId)
            {
                state.IncrementRecursion();
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }

            if (state.TryAcquireUncontended(threadId))
            {
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }
        }

        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_BUSY);
    }

    [SysAbiExport(
        Nid = "2Z+PpY6CaJg",
        ExportName = "pthread_mutex_unlock",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadMutexUnlock(CpuContext ctx)
    {
        var mutexAddress = ResolveMutexAddress(ctx, ctx[CpuRegister.Rdi]);
        if (mutexAddress == 0)
        {
            return SetResult(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        if (!_mutexStates.TryGetValue(mutexAddress, out var state))
        {
            // A statically initialized mutex can be observed as already
            // unlocked before the first lock materializes its state.
            return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
        }

        var threadId = KernelPthreadState.GetCurrentThreadHandle();
        var becameAvailable = false;

        lock (state.SyncRoot)
        {
            if (state.OwnerThreadId == 0)
            {
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }

            if (state.OwnerThreadId != threadId)
            {
                return SetResult(
                    ctx,
                    OrbisGen2Result.ORBIS_GEN2_ERROR_PERMISSION_DENIED);
            }

            if (state.RecursionCount > 1)
            {
                state.DecrementRecursion();
            }
            else
            {
                state.OwnerThreadId = 0;
                state.RecursionCount = 0;
                becameAvailable = true;
            }
        }

        if (becameAvailable)
        {
            _ = GuestThreadExecution.Scheduler?.WakeBlockedThreads(
                state.WakeKey,
                maxCount: 1);
        }

        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    public static int PthreadMutexInit(CpuContext ctx)
    {
        var mutexAddress = ctx[CpuRegister.Rdi];
        if (mutexAddress == 0)
        {
            return SetResult(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        _mutexStates[mutexAddress] = new PthreadMutexState();
        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    public static int PthreadMutexattrInit(CpuContext ctx) =>
        SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);

    public static int PthreadMutexattrSettype(CpuContext ctx) =>
        SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);

    public static int PthreadMutexDestroy(CpuContext ctx)
    {
        var mutexAddress = ResolveMutexAddress(ctx, ctx[CpuRegister.Rdi]);
        if (mutexAddress != 0)
        {
            _mutexStates.TryRemove(mutexAddress, out _);
        }

        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    internal static ulong ResolveMutexAddress(CpuContext ctx, ulong address)
    {
        if (address == 0)
        {
            return 0;
        }

        if (KernelMemoryCompatExports.TryReadUInt64Compat(
                ctx,
                address,
                out var handle) &&
            handle != 0 &&
            (handle == address || _mutexStates.ContainsKey(handle)))
        {
            return handle;
        }

        return address;
    }

    private static int SetResult(
        CpuContext ctx,
        OrbisGen2Result result)
    {
        ctx[CpuRegister.Rax] = unchecked((ulong)(int)result);
        return 0;
    }
}
