// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using SharpEmu.HLE;

namespace SharpEmu.Libs.Kernel;

/// <summary>
/// PS5 libc.prx pthread compatibility exports.
/// </summary>
public static class KernelPthreadLibcStartupExports
{
    [SysAbiExport(
        Nid = "cmo1RIYva9o",
        ExportName = "scePthreadMutexInit",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadMutexInit(CpuContext ctx)
    {
        var slotAddress = ctx[CpuRegister.Rdi];
        if (slotAddress == 0)
        {
            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        KernelPthreadCompatExports._mutexStates[slotAddress] =
            new KernelPthreadCompatExports.PthreadMutexState();

        if (!KernelMemoryCompatExports.TryWriteUInt64Compat(
                ctx,
                slotAddress,
                slotAddress))
        {
            KernelPthreadCompatExports._mutexStates.TryRemove(
                slotAddress,
                out _);

            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_MEMORY_FAULT);
        }

        return Complete(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    [SysAbiExport(
        Nid = "F8bUHwAG284",
        ExportName = "scePthreadMutexattrInit",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadMutexattrInit(CpuContext ctx)
    {
        var attrAddress = ctx[CpuRegister.Rdi];
        if (attrAddress == 0)
        {
            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        if (!KernelMemoryCompatExports.TryWriteUInt64Compat(
                ctx,
                attrAddress,
                0))
        {
            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_MEMORY_FAULT);
        }

        return Complete(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    [SysAbiExport(
        Nid = "iMp8QpE+XO4",
        ExportName = "scePthreadMutexattrSettype",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadMutexattrSettype(CpuContext ctx) =>
        KernelPthreadCompatExports.PthreadMutexattrSettype(ctx);

    [SysAbiExport(
        Nid = "smWEktiyyG0",
        ExportName = "scePthreadMutexattrDestroy",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadMutexattrDestroy(CpuContext ctx)
    {
        var attrAddress = ctx[CpuRegister.Rdi];
        if (attrAddress != 0)
        {
            _ = KernelMemoryCompatExports.TryWriteUInt64Compat(
                ctx,
                attrAddress,
                0);
        }

        return Complete(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    [SysAbiExport(
        Nid = "9UK1vLZQft4",
        ExportName = "scePthreadMutexLock",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadMutexLock(CpuContext ctx)
    {
        var resolved = KernelPthreadCompatExports.ResolveMutexAddress(
            ctx,
            ctx[CpuRegister.Rdi]);

        if (resolved == 0)
        {
            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        ctx[CpuRegister.Rdi] = resolved;
        return KernelPthreadCompatExports.PthreadMutexLock(ctx);
    }

    [SysAbiExport(
        Nid = "tn3VlD0hG60",
        ExportName = "scePthreadMutexUnlock",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadMutexUnlock(CpuContext ctx)
    {
        var resolved = KernelPthreadCompatExports.ResolveMutexAddress(
            ctx,
            ctx[CpuRegister.Rdi]);

        if (resolved == 0)
        {
            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        ctx[CpuRegister.Rdi] = resolved;
        return KernelPthreadCompatExports.PthreadMutexUnlock(ctx);
    }

    [SysAbiExport(
        Nid = "mkx2fVhNMsg",
        ExportName = "pthread_cond_broadcast",
        Target = Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadCondBroadcast(CpuContext ctx)
    {
        var condAddress = ctx[CpuRegister.Rdi];
        if (condAddress == 0)
        {
            return Complete(
                ctx,
                OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);
        }

        var state = ResolveConditionState(ctx, condAddress);
        _ = GuestThreadExecution.Scheduler?.WakeBlockedThreads(
            state.WakeKey,
            int.MaxValue);

        return Complete(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }

    private static KernelPthreadCompatExports.PthreadCondState ResolveConditionState(
        CpuContext ctx,
        ulong address)
    {
        if (KernelPthreadCompatExports._condStates.TryGetValue(
                address,
                out var direct))
        {
            return direct;
        }

        if (KernelMemoryCompatExports.TryReadUInt64Compat(
                ctx,
                address,
                out var handle) &&
            handle != 0 &&
            KernelPthreadCompatExports._condStates.TryGetValue(
                handle,
                out var indirect))
        {
            KernelPthreadCompatExports._condStates[address] = indirect;
            return indirect;
        }

        return KernelPthreadCompatExports._condStates.GetOrAdd(
            address,
            static _ => new KernelPthreadCompatExports.PthreadCondState());
    }

    private static int Complete(
        CpuContext ctx,
        OrbisGen2Result result)
    {
        ctx[CpuRegister.Rax] = unchecked((ulong)(int)result);
        return (int)result;
    }
}
