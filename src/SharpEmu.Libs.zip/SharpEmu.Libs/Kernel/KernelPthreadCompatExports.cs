// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using System.Collections.Concurrent;
using System.Threading;
using SharpEmu.HLE;

namespace SharpEmu.Libs.Kernel;

public static partial class KernelPthreadCompatExports
{
    private static long _nextThreadId = 1000;

    internal static readonly ConcurrentDictionary<ulong, PthreadMutexState> _mutexStates = new();

    internal static readonly ConcurrentDictionary<ulong, PthreadCondState> _condStates = new();


    [SysAbiExport(
        Nid = "EotR8a3ASf4",
        ExportName = "pthread_self",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadSelf(CpuContext ctx)
    {
        int id = unchecked((int)Interlocked.Increment(ref _nextThreadId));

        ctx[CpuRegister.Rax] = unchecked((ulong)id);

        return 0;
    }


    [SysAbiExport(
        Nid = "7Xl257M4VNI",
        ExportName = "pthread_equal",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadEqual(CpuContext ctx)
    {
        int a = unchecked((int)ctx[CpuRegister.Rdi]);
        int b = unchecked((int)ctx[CpuRegister.Rsi]);

        ctx[CpuRegister.Rax] = a == b ? 1UL : 0UL;

        return 0;
    }


    [SysAbiExport(
        Nid = "aI+OeCz8xrQ",
        ExportName = "scePthreadSelf",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int ScePthreadSelf(CpuContext ctx)
    {
        return PthreadSelf(ctx);
    }



    internal sealed class PthreadMutexState
    {
        public object SyncRoot { get; } = new();

        public ulong WakeKey { get; set; }

        public int OwnerThreadId { get; set; }

        public int RecursionCount { get; set; }


        public bool TryAcquireUncontended(int threadId)
        {
            if (OwnerThreadId != 0)
                return false;

            OwnerThreadId = threadId;
            RecursionCount = 1;

            return true;
        }


        public void IncrementRecursion()
        {
            RecursionCount++;
        }


        public void DecrementRecursion()
        {
            if (RecursionCount > 0)
                RecursionCount--;
        }
    }



    internal sealed class PthreadCondState
    {
        public object SyncRoot { get; } = new();

        public int Waiters { get; set; }
    }



    [SysAbiExport(
        Nid = "7H0iTOciTLo",
        ExportName = "pthread_mutex_lock",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadMutexLock(CpuContext ctx)
    {
        ulong mutexAddress = ctx[CpuRegister.Rdi];

        if (!_mutexStates.TryGetValue(mutexAddress, out var state))
            return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);


        int threadId =
            unchecked((int)KernelPthreadState.GetCurrentThreadHandle());


        lock (state.SyncRoot)
        {
            if (state.OwnerThreadId == threadId)
            {
                state.IncrementRecursion();

                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }


            while (!state.TryAcquireUncontended(threadId))
            {
                Monitor.Wait(state.SyncRoot);
            }
        }


        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }



    [SysAbiExport(
        Nid = "K-jXhbt2gn4",
        ExportName = "pthread_mutex_trylock",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadMutexTrylock(CpuContext ctx)
    {
        ulong mutexAddress = ctx[CpuRegister.Rdi];

        if (!_mutexStates.TryGetValue(mutexAddress, out var state))
            return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);


        int threadId =
            unchecked((int)KernelPthreadState.GetCurrentThreadHandle());


        lock (state.SyncRoot)
        {
            if (state.OwnerThreadId == threadId)
            {
                state.IncrementRecursion();

                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
            }


            if (state.TryAcquireUncontended(threadId))
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
        }


        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_BUSY);
    }



    [SysAbiExport(
        Nid = "2Z+PpY6CaJg",
        ExportName = "pthread_mutex_unlock",
        Target = Generation.Gen4 | Generation.Gen5,
        LibraryName = "libKernel")]
    public static int PthreadMutexUnlock(CpuContext ctx)
    {
        ulong mutexAddress = ctx[CpuRegister.Rdi];

        if (!_mutexStates.TryGetValue(mutexAddress, out var state))
            return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_INVALID_ARGUMENT);


        int threadId =
            unchecked((int)KernelPthreadState.GetCurrentThreadHandle());


        lock (state.SyncRoot)
        {
            if (state.OwnerThreadId != threadId)
                return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_ERROR_PERMISSION_DENIED);


            if (state.RecursionCount > 1)
            {
                state.DecrementRecursion();
            }
            else
            {
                state.OwnerThreadId = 0;
                state.RecursionCount = 0;

                Monitor.Pulse(state.SyncRoot);
            }
        }


        return SetResult(ctx, OrbisGen2Result.ORBIS_GEN2_OK);
    }



    // Chamado internamente pelos testes/kernel
    // Sem SysAbiExport até obter NID real
    public static int PthreadMutexInit(CpuContext ctx)
    {
        ulong mutexAddress = ctx[CpuRegister.Rdi];

        _mutexStates[mutexAddress] =
            new PthreadMutexState();

        return SetResult(
            ctx,
            OrbisGen2Result.ORBIS_GEN2_OK);
    }



    public static int PthreadMutexattrInit(CpuContext ctx)
    {
        return SetResult(
            ctx,
            OrbisGen2Result.ORBIS_GEN2_OK);
    }



    public static int PthreadMutexattrSettype(CpuContext ctx)
    {
        return SetResult(
            ctx,
            OrbisGen2Result.ORBIS_GEN2_OK);
    }



    public static int PthreadMutexDestroy(CpuContext ctx)
    {
        ulong mutexAddress = ctx[CpuRegister.Rdi];

        _mutexStates.TryRemove(
            mutexAddress,
            out _);

        return SetResult(
            ctx,
            OrbisGen2Result.ORBIS_GEN2_OK);
    }



    private static int SetResult(
        CpuContext ctx,
        OrbisGen2Result result)
    {
        ctx[CpuRegister.Rax] = (ulong)result;

        return 0;
    }
}