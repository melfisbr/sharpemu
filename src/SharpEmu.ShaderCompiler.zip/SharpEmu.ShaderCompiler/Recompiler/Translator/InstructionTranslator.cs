using SharpEmu.ShaderCompiler.Decoder;

namespace SharpEmu.ShaderCompiler.Recompiler.Translator;

public sealed class InstructionTranslator
{
    private readonly RecompilerContext _context;


    public InstructionTranslator(
        RecompilerContext context)
    {
        _context = context;
    }


    public void Translate(
        DecodedInstruction instruction)
    {

        switch(instruction.Opcode)
        {

            case Opcode.V_ADD_F32:

                TranslateVAddF32(
                    instruction);

                break;


            case Opcode.V_MUL_F32:

                TranslateVMulF32(
                    instruction);

                break;


            default:

                throw new NotSupportedException(
                    $"Opcode {instruction.Opcode} not implemented");

        }

    }
}