// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using SharpEmu.ShaderCompiler.IR;
using SharpEmu.ShaderCompiler.Decoder;

namespace SharpEmu.ShaderCompiler.Translator;

/// <summary>
/// Converte instruções ISA do PS5 (GCN/RDNA)
/// para a representação intermediária do SharpEmu.
/// 
/// Fluxo:
/// DecodedInstruction
///        ↓
/// IsaToIrTranslator
///        ↓
/// IRInstruction
///        ↓
/// IRModule
/// </summary>
public static class IsaToIrTranslator
{
    /// <summary>
    /// Traduz uma lista de instruções decodificadas para IR.
    /// </summary>
    public static IRModule Translate(
        IReadOnlyList<DecodedInstruction> instructions)
    {
        var module = new IRModule();

        foreach (var instruction in instructions)
        {
            TranslateInstruction(
                module,
                instruction);
        }

        return module;
    }


    /// <summary>
    /// Traduz uma instrução ISA individual.
    /// </summary>
    private static void TranslateInstruction(
        IRModule module,
        DecodedInstruction instruction)
    {
        IRInstruction irInstruction =
            instruction.Format switch
            {
                InstructionFormat.SOP =>
                    TranslateScalarInstruction(instruction),

                InstructionFormat.VOP =>
                    TranslateVectorInstruction(instruction),

                InstructionFormat.SMEM =>
                    TranslateMemoryInstruction(instruction),

                InstructionFormat.BUFFER =>
                    TranslateBufferInstruction(instruction),

                InstructionFormat.IMAGE =>
                    TranslateImageInstruction(instruction),

                _ =>
                    CreateUnknownInstruction(instruction)
            };


        module.AddInstruction(irInstruction);
    }



    private static IRInstruction TranslateScalarInstruction(
        DecodedInstruction instruction)
    {
        return new IRInstruction
        {
            Opcode = TranslateOpcode(
                instruction.Opcode),

            Operands =
                ConvertOperands(
                    instruction),

            Type = IRType.Int32
        };
    }



    private static IRInstruction TranslateVectorInstruction(
        DecodedInstruction instruction)
    {
        return new IRInstruction
        {
            Opcode = TranslateOpcode(
                instruction.Opcode),

            Operands =
                ConvertOperands(
                    instruction),

            Type = IRType.Float32
        };
    }



    private static IRInstruction TranslateMemoryInstruction(
        DecodedInstruction instruction)
    {
        return new IRInstruction
        {
            Opcode = IROpcode.Load,

            Operands =
                ConvertOperands(
                    instruction),

            Type = IRType.UInt32
        };
    }



    private static IRInstruction TranslateBufferInstruction(
        DecodedInstruction instruction)
    {
        return new IRInstruction
        {
            Opcode = IROpcode.Load,

            Operands =
                ConvertOperands(
                    instruction),

            Type = IRType.UInt32
        };
    }



    private static IRInstruction TranslateImageInstruction(
        DecodedInstruction instruction)
    {
        return new IRInstruction
        {
            Opcode = IROpcode.SampleTexture,

            Operands =
                ConvertOperands(
                    instruction),

            Type = IRType.Vector4
        };
    }



    private static IRInstruction CreateUnknownInstruction(
        DecodedInstruction instruction)
    {
        return new IRInstruction
        {
            Opcode = IROpcode.Nop
        };
    }



    private static IROpcode TranslateOpcode(
        int opcode)
    {
        return opcode switch
        {
            0x01 => IROpcode.Add,
            0x02 => IROpcode.Sub,
            0x03 => IROpcode.Mul,

            0x10 => IROpcode.Load,
            0x11 => IROpcode.Store,

            0x20 => IROpcode.Compare,

            0x30 => IROpcode.Branch,

            _ => IROpcode.Nop
        };
    }



    private static List<IRValue> ConvertOperands(
        DecodedInstruction instruction)
    {
        var operands = new List<IRValue>();

        foreach (var operand in instruction.Operands)
        {
            operands.Add(
                new IRValue
                {
                    Id = operand.Register,
                    Type = IRType.UInt32
                });
        }

        return operands;
    }
}