// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later


namespace SharpEmu.ShaderCompiler.Decoder;



public static class OperandDecoder
{


    public static Operand DecodeVGPR(
        int index)
    {
        return new Operand
        {
            Type = OperandType.VGPR,
            Index = index
        };
    }



    public static Operand DecodeSGPR(
        int index)
    {
        return new Operand
        {
            Type = OperandType.SGPR,
            Index = index
        };
    }



    public static Operand DecodeImmediate(
        uint value)
    {
        return new Operand
        {
            Type = OperandType.Immediate,
            Value = value
        };
    }

}