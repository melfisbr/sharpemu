using System;
using System.Runtime.CompilerServices;

namespace SharpEmu.CLI;

/// <summary>
/// V74.0.112.2.4 - hardware-aware Demon's Souls host feed envelope.
///
/// This envelope does not increase queue counts or widen CPU->GPU buffering.
/// When Vulkan exposes the existing second physical queue, V76.3.8.3 keeps the
/// proven 18/96/4/6/12 feed limits and synchronizes graphics/compute by exact
/// guest resource hazards plus explicit guest waits instead of lane alternation.
/// V112.2.3 empirically regressed PPSA01341 when the buffering envelope itself
/// was widened from 18/96/4/6/12 to 24/96/8/6/16.
/// </summary>
// SHARPEMU_V74_0_117_1_1_7_2_CONTRACT_SAFE_STABLE_ENVELOPE
internal static class DemonsSoulsGpuQueueEnvelopeV74011224
{
    private const string Marker = "SHARPEMU_V74_0_112_2_4_GPU_QUEUE_ENVELOPE";

    [ModuleInitializer]
    internal static void Apply()
    {
        if (!IsDemonsSoulsLaunch())
        {
            return;
        }

        // V76.3.14.7.1: V76.3.1 boot ownership A/B rebased on the actual
        // V76.3.8.6 CLI envelope. This does not auto-start or skip movies.
        // RUN_4 also sets these before process start so the cached media
        // ownership decision is made in guest mode from the first access.
        Set("SHARPEMU_BINK_FORCE_GUEST", "0");
        Set("SHARPEMU_BINK_ALLOW_HOST_DECODER", "1");

        Set("SHARPEMU_PENDING_GUEST_WORK_ITEMS", "192");
        // V76.3.15.0 - merge do source historico ~5 FPS com a cadeia atual.
        // Profundidade volta ao source de 20/08, mas byte budget, FIFO, waits,
        // hazards e producer closure modernos permanecem.  Estes Set() sao
        // intencionalmente title-authoritative para o EXE direto nao depender
        // das variaveis do PowerShell de diagnostico.
        Set("SHARPEMU_PENDING_GUEST_WORK_MB", "96");
        Set("SHARPEMU_MAX_GUEST_WORK_PER_RENDER", "1024");
        Set("SHARPEMU_QUEUE_MAX_INFLIGHT", "16");
        Set("SHARPEMU_QUEUE_LANE_BURST", "4");

        Set("SHARPEMU_DUAL_PHYSICAL_QUEUE", "0");

        Set("SHARPEMU_AGC_GATE_OWNER_WAIT_DRAIN", "0");
        Set("SHARPEMU_AGC_GATE_QUANTUM_PACKETS", "32");
        Set("SHARPEMU_AGC_GATE_QUANTUM_MS", "1");
        Set("SHARPEMU_DEDICATED_WAIT_DRAIN", "1");
        Set("SHARPEMU_AGC_DEDICATED_NONBLOCKING_GATE", "1");
        Set("SHARPEMU_AGC_DEDICATED_FAST_ONLY", "1");
        Set("SHARPEMU_AGC_SUBMIT_EVIDENCE_WAIT_DRAIN", "1");

        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE", "1");
        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_AGE_MS", "300");
        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_MAX_ITEMS", "128");
        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_LIFETIME_MS", "5000");

        Set("SHARPEMU_CPU_CACHE_AWARE", "1");
        Set("SHARPEMU_CPU_CACHE_POLICY", "compact");

        // Historical V7.8.1 path: only a NATURAL guest .bk2 request may arm
        // HostMovieBridge/FFmpeg. No auto-boot and no fake completion.
        Set("SHARPEMU_BINK_FORCE_GUEST", "0");
        Set("SHARPEMU_BINK_ALLOW_HOST_DECODER", "1");
        Set("SHARPEMU_BINK_HYBRID_HOST", "1");
        Set("SHARPEMU_BINK_AUTO_BOOT", "0");
        Set("SHARPEMU_KYTY_QUEUE_SUBMISSION_BURST", "4");
        Set("SHARPEMU_RESERVED_HOST_LANES", "6");
        Set("SHARPEMU_MAX_INFLIGHT_GUEST_SUBMISSIONS", "16");
        Set("SHARPEMU_DS_SAFE_MEMCOPY_V763151", "1");
        // V76.3.17.0.1 - asynchronous AGC command processor.
        Set("SHARPEMU_AGC_ASYNC_COMMAND_PROCESSOR", "1");
        Set("SHARPEMU_AGC_ASYNC_CP_MAX_INGRESS", "1024");
        // V76.3.17.1 - bounded compute chain.
        // Hazard classification and broad Vulkan memory barrier are unchanged.
        Set("SHARPEMU_COMPUTE_CHAIN_MAX_V763171", "4");

        // V76.3.16.0 - semantic FIFO reform.
        //
        // Host-only EVENT_WRITE and acquire-no-flush controls retain their exact
        // logical sequence but share physical scheduler nodes. They cannot become
        // priority-sync work and may be consumed between adjacent same-submission
        // draws without closing the Vulkan payload command buffer.
        //
        // RELEASE_MEM/EOP, WRITE_DATA producers, WAIT_REG_MEM, queue completion,
        // global/GPU->CPU visibility and presentation remain hard boundaries.
        Set("SHARPEMU_HOST_ONLY_SIDEBAND", "1");
        Set("SHARPEMU_HOST_ONLY_SIDEBAND_MAX", "64");

        // Sideband supersedes the old dequeue-time ordered microbatch.
        Set("SHARPEMU_ORDERED_ACTION_MICROBATCH", "0");

        // Keep the proven draw batching path. Do not re-enable the naive generic
        // FIFO payload train: V117.3.4 measured 365 draws/s vs 396 baseline.
        Set("SHARPEMU_DRAW_COMMAND_BUFFER", "1");
        Set("SHARPEMU_DRAW_COMMAND_BUFFER_MAX", "8");
        Set("SHARPEMU_FIFO_PAYLOAD_TRAIN_MAX", "1");
        Set("SHARPEMU_PRESERVE_PAYLOAD_BATCH", "1");

        // Producer-backed WAIT_REG_MEM wakeups remain immediate/latch-driven.
        // Only producer-less CPU-write/deadlock fallback scans are relaxed.
        Set("SHARPEMU_WAIT_FULL_SCAN_MIN_MS", "32");
        Set("SHARPEMU_DEDICATED_WAIT_DRAIN", "1");
        Set("SHARPEMU_AGC_DEDICATED_FAST_ONLY", "1");
        Set("SHARPEMU_AGC_SUBMIT_EVIDENCE_WAIT_DRAIN", "1");

        // V76.3.8.3 structural queue contract. Keep explicit guest waits and
        // byte-range RAW/WAR/WAW hazards, but do not serialize the entire
        // opposite host lane merely because work alternates between ACB compute
        // and DCB graphics. Utility image transitions/copies now publish their
        // guest ranges to the same tracker before this policy is enabled.
        Set("SHARPEMU_DUAL_QUEUE_RESOURCE_SYNC", "1");
        Set("SHARPEMU_DUAL_QUEUE_SYNC_POLICY", "resource");
        Set("SHARPEMU_BINK_STRICT_RESOURCE_SCOPE", "1");
        Set("SHARPEMU_BINK_PROVEN_COMPUTE_PAIR2", "1");

        // CPU topology tuning is independent of guest/GPU synchronization.
        // Keep it cache-aware, physical-core-first and non-verifying in normal
        // runs; diagnostics may explicitly enable verification/logging.
        SetDefault("SHARPEMU_CPU_CACHE_AWARE", "1");
        SetDefault("SHARPEMU_CPU_CACHE_POLICY", "auto");
        SetDefault("SHARPEMU_CPU_CACHE_VERIFY", "0");

        Set("SHARPEMU_BARRIERED_COMPUTE_BATCH", "0");
        // V76.3.5: keep the old broad V99 batching disabled. Allow only the
        // V117.7 two-dispatch pair when overlap is the sole hazard; the
        // presenter inserts a full Vulkan memory barrier at the pair edge.
        Set("SHARPEMU_COMPUTE_WRITE_OVERLAP_PAIR_BARRIER", "1");
        // V76.3.4.1 A/B regressed the V76.3.3 median and increased producer
        // waits. Restore V76.3.3 RELEASE_MEM behavior for the normal path.
        Set("SHARPEMU_DEFER_RELEASE_QUEUE_COMPLETION", "0");
        Set("SHARPEMU_CLOSED_COMPUTE_SUBMIT_GROUP", "0");
        // V74.0.117.2: scheduling precision without widening the proven envelope.
        Set("SHARPEMU_FIFO_WATCHED_PRODUCER_ASSIST", "1");
        Set("SHARPEMU_FIFO_WATCHED_PRODUCER_SCAN_DEPTH", "512");
        Set("SHARPEMU_WATCHED_WRITE_CONTROL_LANE", "0");
        Set("SHARPEMU_SYNC_PRIORITY_REAL_WAIT_ONLY", "1");
        // V74.0.117.3.4: bounded presenter FIFO payload train. Scheduling
        // locality only: no cross-queue command-buffer merge, no wait bypass.
        // V117.3.4 FIFO locality measured 365 draws/s vs 396 baseline and only
        // reached train_work=3. Disable the train while retaining V117.2 waiter
        // fairness/producer precision; optimize the physical submit boundary.
        Set("SHARPEMU_FIFO_PAYLOAD_TRAIN_MAX", "1");
        Set("SHARPEMU_GRAPHICS_COMPUTE_SINGLE_COALESCE", "1");
        // V117.7: only the second direct compute whose guest resource ranges
        // are known and non-overlapping may share the current command buffer.
        Set("SHARPEMU_DISJOINT_COMPUTE_PAIR2", "1");
        // SHARPEMU_V74_0_117_11_SHADER_PROCESSING_ENVELOPE
        // Cache only PVM region/protection validation for large live reads.
        // Guest bytes are copied on every TryRead and are never cached here.
        Set("SHARPEMU_SHADER_PVM_READ_ACCESS_CACHE", "1");
        // SHARPEMU_V74_0_117_12_SHADER_RESOURCE_SINGLE_COPY
        // Read-only shader global resources are described in the evaluator and
        // copied once from live guest memory directly into Vulkan staging.
        Set("SHARPEMU_SHADER_DEFER_GLOBAL_READS", "1");
        // SHARPEMU_V74_0_117_13_SHADER_GLOBAL_RESIDENCY_ENVELOPE
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY", "1");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MB", "256");

        // SHARPEMU_V74_0_117_14_PRODUCER_CRITICAL_PATH_ENVELOPE
        // Normal payload queue remains 18. A temporary cap of 48 is available
        // only when AGC preindex proves that the current logical submission
        // contains a future producer for a live WAIT_REG_MEM range.
        Set("SHARPEMU_PENDING_GUEST_WORK_PRODUCER_ITEMS", "48");
        Set("SHARPEMU_PLANNED_PRODUCER_QUEUE_PRIORITY", "1");
        // V76.3.8.5: normal payload cap stays 18. With a live waiter and a
        // sync-dominated queue, allow only six extra parser-visible payloads
        // until AGC can prove the exact producer (then the existing cap 48
        // applies). Does not change max inflight or Vulkan submission policy.
        Set("SHARPEMU_PENDING_GUEST_WORK_WAITER_ITEMS", "24");

        // SHARPEMU_V74_0_117_16_DESCRIPTOR_SET_CACHE_ENVELOPE
        Set("SHARPEMU_DESCRIPTOR_SET_CACHE_V11716", "1");
        Set("SHARPEMU_DESCRIPTOR_SET_CACHE_MAX_SETS_V11716", "2048");

        // SHARPEMU_V74_0_118_0_GPU_RESIDENT_SHADER_ENVELOPE
        Set("SHARPEMU_GPU_RESIDENT_SHADER_V1180", "1");
        Set("SHARPEMU_GPU_RESIDENT_SHADER_MAX_V1180", "4096");

        // SHARPEMU_V76_3_3_REBAR_HOTSET_RUNTIME_SCALAR
        // V76.3.2 admitted 1024 persistent globals and drove the transient BAR
        // path into tens of thousands of allocation fallbacks. Preserve ReBAR
        // for transient traffic: only genuinely hot immutable globals become
        // resident, resident buffers use normal DEVICE_LOCAL memory after one
        // upload, and the tiny per-draw/per-compute runtime scalar SSBOs bind
        // directly from pooled mapped storage without staging/copy commands.
        Set("SHARPEMU_GPU_RESIDENT_SHADER_MAX_V1180", "1024");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY", "1");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MB", "256");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MAX_ENTRIES", "512");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MIN_KB", "64");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_HOT_ADMIT", "1");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_ADMIT_OBSERVATIONS", "5");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_REBAR_PAUSE_FALLBACKS", "32");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_LARGE_KB", "1024");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_LARGE_ADMIT_OBSERVATIONS", "3");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MEDIUM_KB", "256");
        Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MEDIUM_ADMIT_OBSERVATIONS", "4");

        // V76.3.7.8: V76.3.7.7 measured virtually no set-associative conflict
        // evictions, so the 4-way lookup/move-to-front path was overhead without
        // evidence of a collision benefit. Return to the V76.3.5 direct-mapped
        // 4096-slot cache and shrink the shared immutable decode dictionaries.
        Set("SHARPEMU_SHADER_THREAD_CACHE_SLOTS", "4096");
        Set("SHARPEMU_SHADER_DECODE_CACHE_MAX", "4096");
        Set("SHARPEMU_SHADER_METADATA_CACHE_MAX", "4096");

        // V76.3.7.8.1: restore the exact WAIT monitor timing used by the
        // last known-good V76.3.7.7 boot. V76.3.7.8 changed only timing and
        // frontend parameters, then exposed an early guest-thread NULL execute
        // in NexusRevolution Surveillance before the GPU frontend started.
        // Keep the V76.3.7.8 frontend cache recovery, but isolate WAIT timing.
        // No wait is force-satisfied and no watched label/barrier semantics change.
        Set("SHARPEMU_WAIT_SOFT_CAP_MS", "20");
        Set("SHARPEMU_WAIT_MONITOR_MAX_MS", "4");
        Set("SHARPEMU_SHADER_SINGLEFLIGHT_V1190", "1");
        Set("SHARPEMU_REBAR_GLOBAL_DIRECT_V1190", "1");
        Set("SHARPEMU_RUNTIME_SCALAR_DIRECT_V7633", "1");
        Set("SHARPEMU_RUNTIME_SCALAR_DIRECT_MAX_KB_V7633", "8");
        Set("SHARPEMU_VK_HOST_BUFFER_CACHE_MB", "128");

        // 512 cached descriptor sets saturated in the V76.3.0 capture and
        // forced late layouts back through vkAllocateDescriptorSets. 2048 is
        // still bounded and fits the existing implementation limit (4096).
        Set("SHARPEMU_DESCRIPTOR_SET_CACHE_MAX_SETS_V11716", "2048");

        // Pipeline-cache export calls vkGetPipelineCacheData and writes a
        // ~70-80 MiB blob. Keep shutdown persistence, but move periodic saves
        // out to five minutes instead of every 30 seconds.
        Set("SHARPEMU_VK_PIPELINE_CACHE_SAVE_INTERVAL_S", "300");

        // Profiling is diagnostic work. Do not force timestamp scopes and
        // pipeline timing on every Release gameplay run; RUN_4_DIAGNOSTIC can
        // explicitly opt them back in.
        SetDefault("SHARPEMU_PROFILE_RENDER", "0");
        SetDefault("SHARPEMU_PROFILE_RENDER_REPORT_S", "5");
        SetDefault("SHARPEMU_TRACE_SHADER_PIPELINE_TIMING", "0");

        // V76.3.2: strict guest-Bink ordering is a decode activity lease, not
        // a file-descriptor lifetime. 500 ms safely covers 30/60 fps YUV
        // producer cadence while releasing normal graphics/compute overlap as
        // soon as a movie decoder becomes idle.
        SetDefault("SHARPEMU_BINK_GUEST_STRICT_IDLE_MS", "500");
        Console.Error.WriteLine(
            "[V76.3.16.0][SEMANTIC_FIFO_PROFILE] " +
            "host_sideband=1 sideband_max=64 priority_sync=real-boundary-only " +
            "ordered_microbatch=off draw_buffer=8 generic_payload_train=off " +
            "wait_wake=producer-latched fullscan_fallback_ms=32 " +
            "queue=192/96 burst=4 inflight=16 single_vkqueue=1");
        // V76.3.16.0.1 - regression rollback.
        // V16 created one sideband node per logical action (no compaction)
        // and zero draw bridges, so the semantic-priority change had only
        // downside. Restore the proven V15.1 execution contract.
        Set("SHARPEMU_HOST_ONLY_SIDEBAND", "0");
        Set("SHARPEMU_ORDERED_ACTION_MICROBATCH", "1");
        Set("SHARPEMU_WAIT_FULL_SCAN_MIN_MS", "16");

        // V76.3.16.1.1 - dependency-driven producer scheduling only.
        // The acquire no-op experiment from V16.1 was removed completely.
        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SLICES", "1");
        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_MAX_SLICES", "8");
        Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SLICE_PAUSE_US", "1000");

        Console.Error.WriteLine(
            "[V76.3.17.1][COMPUTE_CHAIN4_BROAD_PROFILE] " +
            "chain_max=4 edge_validation=v1177-adjacent " +
            "barrier=all-commands-memory-rw unchanged=waits+hazards+visibility " +
            "async_agc=v1701 sideband=off microbatch=on");
        Console.Error.WriteLine(
            "[V76.3.17.0.1][ASYNC_AGC_CP_ADAPTIVE] " +
            "source=current-434d7980 guest_submit=publish-only " +
            "command_processor=dedicated-thread ingress_max=1024 " +
            "pm4_parser=existing waits=unchanged hazards=unchanged " +
            "presenter=current-branch");
        Console.Error.WriteLine(
            "[V76.3.16.1.1][DEPENDENCY_SLICED_PRODUCER] " +
            "slices=8x128 pause_us=1000 lifetime_ms=5000 same_queue_fifo=1 " +
            "sibling_fairness=1 acquire_fastpath=off sideband=off microbatch=on " +
            "queue=192/96 burst=4 inflight=16 single_vkqueue=1");
        Console.Error.WriteLine(
            "[V76.3.16.0.1][SIDEBAND_REGRESSION_ROLLBACK] " +
            "presenter=v15.1-exact host_sideband=0 ordered_microbatch=1 " +
            "wait_fullscan_ms=16 queue=192/96 burst=4 inflight=16 " +
            "safe_memcpy=preserved waits=preserved hazards=preserved");
        Console.Error.WriteLine(
            "[V76.3.15.1][BOOT_LANE6_SAFE_MEMCPY] " +
            "queue=192/96 burst=4 inflight=16 reserved_lanes=6 " +
            "single_vkqueue=1 safe_memcpy=chunked-read-write " +
            "waits=unchanged hazards=unchanged bink=unchanged");
        Console.Error.WriteLine(
            "[V76.3.14.7.1_BOOT_BINK_OWNERSHIP_REBASE] " +
            "owner=guest-v7631-control host_decoder=off process_env_prearmed=diagnostic " +
            "auto_boot=off queue_wait_resource_stack=preserved");
        Console.Error.WriteLine(
            "[V76.3.2][PERF_LANE_RESTORE] " +
            "bink_strict_activity_lease_ms=500 stale_fd_serialization=off " +
            "normal_graphics_compute_overlap=restore-after-bink-idle");

        Console.Error.WriteLine(
            "[V76.3.8.5][WAITER_PROGRESS_RESERVE] " +
            "normal_payload_items=18 waiter_progress_items=24 planned_producer_items=48 " +
            "activation=live-waiter+sync-majority+unproven-producer " +
            "fifo=unchanged inflight=12 hazards=unchanged fences=unchanged " +
            "guest_wait_values=unchanged");

        Console.Error.WriteLine(
            "[V76.3.8.4.1.1][ADAPTIVE_REBASE_RECOVERY] " +
            "source=current-weighted-closure wait_full_scan=v76383 " +
            "release_mem=v76383 visibility_unblock=exact-fence-scheduler-only " +
            "resource_retirement=unchanged guest_semantics=unchanged");

        Console.Error.WriteLine(
            "[V76.3.8.3][STRUCTURAL_QUEUE_ORDER] " +
            "dual_queue=resource-scoped utility_access_tracking=1 " +
            "bink_strict=resource-scoped bink_pair=proven-max2 " +
            "wait_reg_mem=unchanged write_data=unchanged release_mem=unchanged " +
            "cpu_cache=auto guest_semantics=preserved");

        Console.Error.WriteLine(
            "[V76.3.5][BARRIERED_OVERLAP_PAIR] " +
            "release_eop_defer=0 broad_barrier_batch=0 " +
            "write_overlap_pair=1 max_compute_pair=2 " +
            "barrier=all-commands-memory-rw hazards=conservative");

        Console.Error.WriteLine(
            "[V76.3.7.5][MEMORY_HOTPATH_RECOVERY] " +
            "texture_storage_alias=1 dstselect_sampler_reuse=1 " +
            "stable_probe=3x64B host_cache_mb=128 bink_policy=preserved");

        Console.Error.WriteLine(
            "[V76.3.7.7][STABLE_PRODUCER_VIEW_DEDUP] " +
            "producer_priority=saturation-gated producer_items=48 same_queue_fifo=1 " +
            "global_residency=512/256MB stable_probe=3x64B admit=3-5 " +
            "pvm_read_slots=1024 debug_sgpr_selfcheck=once " +
            "local_view_payload_dedup=1 bink_policy=preserved " +
            "wait_satisfaction=unchanged barriers=unchanged hazards=unchanged");

        Console.Error.WriteLine(
            "[V76.3.7.8][FRONTEND_STABILITY_RECOVERY] " +
            "shader_l2=direct/4096 shared_decode=4096 shared_metadata=4096 " +
            "wait_timing=overridden-by-v763781 producer_policy=v76377-stable " +
            "view_payload_dedup=preserved bink_policy=preserved");

        Console.Error.WriteLine(
            "[V76.3.7.8.1][WAIT_TIMING_RACE_RECOVERY] " +
            "wait_monitor_max_ms=4 wait_soft_cap_ms=20 " +
            "known_good_timing=v76377 frontend=v76378-direct4096 " +
            "wait_satisfaction=unchanged barriers=unchanged hazards=unchanged " +
            "bink_policy=preserved");

        Console.Error.WriteLine(
            "[V76.3.6][MAX_P0_RECOVERY] shader_l2=overridden-by-v76378 " +
            "shared_decode=overridden-by-v76378 global_residency=overridden-by-v76377 " +
            "pvm_read_slots=overridden-by-v76377 wait_monitor=overridden-by-v763781 scratch_bank=32");

        Console.Error.WriteLine(
            "[V76.3.3][REBAR_HOTSET_SCALAR] " +
            "runtime_scalar_direct=1 scalar_max_kb=8 host_cache_mb=128 " +
            "residency=overridden-by-v76377 " +
            "resident_rebar=off rebar_pause_fallbacks=32 descriptor_sets=2048 " +
            "pipeline_cache_save_s=300 profiling=opt-in");

        Console.Error.WriteLine(
            "[V74.0.117.4][SUBMIT_BOUNDARY_REFORM] " +
            "fifo_payload_train=1 graphics_compute_single_coalesce=1 " +
            "one_compute_per_batch=1 candidate_0x4459A200_join=0 " +
            "queue=192/96 burst=4 inflight=16 dual_physical=single " +
            "barriered=0 closed_group=0 write_bypass=0");
        Console.Error.WriteLine(
            "[V74.0.117.7][STRUCTURAL_SUBMIT_REFORM] " +
            "disjoint_compute_pair2=1 max_compute_per_submit=2 " +
            "pair_rule=known-nonoverlap same_queue_submission=1 " +
            "global_write_join=0 metadata_join=0 indirect_join=0 " +
            "device_lost_candidate_join=0 provenance_runtime_optin=1 " +
            "barriered=0 closed_group=0 dual_physical=resource-scoped");
        Console.Error.WriteLine(
            "[V76.3.15.0][5FPS_BASELINE_MERGE] " +
            "donor=src-20260820-133228 donor_perf=v763781 " +
            "pending=192/96 burst=4 inflight=16 reserved_lanes=6 " +
            "single_vkqueue=1 closure128=1 wait_owner_drain=0 " +
            "bink=natural-request-host-ffmpeg auto_boot=off");
        Console.Error.WriteLine(
            "[V74.0.117.2][QUEUE_PRECISION] " +
            "queue_size_merged=192/96 burst=4 max_inflight=16 " +
            "fifo_producer_assist=1 fifo_scan_depth=512 " +
            "sync_priority_real_wait_only=1 write_control_lane=0");

        Console.Error.WriteLine(
            "[V74.0.112.2.4][GPU_QUEUE_ENVELOPE] " +
            "active=1 physical_vkqueue_policy=single " +
            "pending_items=192 pending_mb=96 burst=4 reserved_lanes=6 " +
            "max_inflight=16 barriered=0 closed_group=0");
    }

    private static bool IsDemonsSoulsLaunch()
    {
        foreach (var arg in Environment.GetCommandLineArgs())
        {
            if (arg.Contains("PPSA01341", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        var titleId = Environment.GetEnvironmentVariable("SHARPEMU_TITLE_ID");
        return string.Equals(titleId, "PPSA01341", StringComparison.OrdinalIgnoreCase);
    }

    private static void Set(string name, string value) =>
        Environment.SetEnvironmentVariable(name, value, EnvironmentVariableTarget.Process);

    private static void SetDefault(string name, string value)
    {
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(name)))
        {
            Set(name, value);
        }
    }

    internal static string VersionMarker => Marker;
}
