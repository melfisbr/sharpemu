// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using System.Collections.Concurrent;
using System.Runtime.CompilerServices;

namespace SharpEmu.Libs.Media;

/// <summary>
/// V76.0.0 guest-owned Bink2 policy.
///
/// PS5 titles that carry Bink2 in the guest executable/module must execute that
/// code through the normal guest CPU path. SharpEmu provides only the generic
/// kernel/filesystem/threading/audio/GPU/VideoOut infrastructure. It must not
/// replace the title decoder, patch Bink headers, inject decoded frames or gate
/// guest execution around a host movie player.
///
/// The historical host bridge remains source-compatible for diagnostics and
/// non-Bink media users, but Bink host ownership is unreachable by default.
/// An explicit SHARPEMU_BINK_ALLOW_HOST_DECODER=1 opt-in is required to enter
/// the legacy host-decoder code paths.
/// </summary>
internal static class BinkGuestOwnedRuntimeV7600
{
    internal const string Marker = "V76.0.0_GUEST_OWNED_BINK2";

    private static readonly ConcurrentDictionary<string, byte> ObservedMovies =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// True for normal SharpEmu execution. This getter intentionally computes
    /// from the environment rather than relying on ModuleInitializer ordering,
    /// so older Bink initializers can safely query it during module startup.
    /// </summary>
    internal static bool Enabled =>
        !string.Equals(
            Environment.GetEnvironmentVariable(
                "SHARPEMU_BINK_ALLOW_HOST_DECODER"),
            "1",
            StringComparison.Ordinal);

    [ModuleInitializer]
    internal static void Initialize()
    {
        if (!Enabled)
        {
            Console.Error.WriteLine(
                "[BINK-GUEST][V76.0.0] legacy_host_decoder_opt_in=True " +
                "guest_owned_default=False");
            return;
        }

        // Force a single owner for title-provided Bink2: the guest. Do not let
        // older module initializers auto-select RAD/NIHAV/FFmpeg based on tools
        // installed on the host.
        Set("SHARPEMU_BINK_MODE", "guest");
        Set("SHARPEMU_BINK_AUTO_BOOT", "0");
        Set("SHARPEMU_BINK_BOOT_SEQUENCE", null);
        Set("SHARPEMU_BINK_NATIVE_PREFER", "0");
        Set("SHARPEMU_BINK_NATIVE_EXCLUSIVE", "0");
        Set("SHARPEMU_BINK_THROTTLE_GUEST_CPU", "0");
        Set("SHARPEMU_BINK_THROTTLE_GUEST_GPU", "0");
        Set("SHARPEMU_BINK_HOST_AUDIO", "0");
        Set("SHARPEMU_DS_INTRO_EXTERNAL_AUDIO", "0");
        Set("SHARPEMU_DS_INTRO_WAVEOUT_CLOCK", "0");
        Set("SHARPEMU_DS_ATTRACT_EMBED_AUDIO", "0");
        Set("SHARPEMU_RAD_POST_ATTRACT_LOOP_INTERNAL", "0");
        Set("SHARPEMU_DEMONS_ATTRACT_GUEST_FRAME_HANDOFF", "0");
        Set("SHARPEMU_BINK_DEDUPE_HOST_BOOT_REPLAY", "0");
        Set("SHARPEMU_BINK_STARTUP_COMPLETION_SHIM", "0");
        Set("SHARPEMU_BINK_DIRECT_PRESENT_ONLY", "0");

        Console.Error.WriteLine(
            "[BINK-GUEST][V76.0.0] guest_owned=True host_decoder=False " +
            "ffmpeg_bink=False nihav_bink=False rad_host=False " +
            "header_shim=False frame_injection=False host_audio=False " +
            "cpu_gate=False gpu_gate=False auto_boot=False");
    }

    internal static bool ObserveGuestMovie(string? hostPath)
    {
        if (!Enabled || string.IsNullOrWhiteSpace(hostPath))
        {
            return false;
        }

        var fileName = Path.GetFileName(hostPath);
        if (ObservedMovies.TryAdd(hostPath, 0))
        {
            Console.Error.WriteLine(
                "[BINK-GUEST][V76.0.0] natural_guest_movie " +
                $"file='{fileName}' action=observe-only " +
                "host_takeover=False header_patch=False wait=False");
        }

        // Important: false means HostMovieBridge did not take ownership. The
        // caller must continue opening/reading the original guest asset.
        return false;
    }

    private static void Set(string name, string? value) =>
        Environment.SetEnvironmentVariable(
            name,
            value,
            EnvironmentVariableTarget.Process);
}
