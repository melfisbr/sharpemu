# CHANGELOG V76.0.10.4

- Corrige semântica RDNA2 de FI/BOUND_CTRL em V_PERMLANE16_B32 e V_PERMLANEX16_B32.
- Corrige write suppression DPP16 para BOUND_OFF + FI=0 + source lane inativa.
- Preserva VDST em vez de gravar zero quando o hardware suprime a escrita.
- Invalida cache SPIR-V antigo via CacheVersion V76.0.10-r2.
- Preserva V76.0.10.2 SOPP semantic fix, V76.0.10.3 DS_SWIZZLE, Wave64, MTBUF/D16, typed stores e guest-owned Bink.
