# SharpEmu V76.0.10.4 — RDNA2 DPP / PERMLANE Bound Control SAFE

Baseline obrigatório: V76.0.10.3 DS_SWIZZLE Adaptive Rebase instalado e verificado.

## Diagnóstico

O runtime atual prova que o Bink guest continua executando compute e que os planos finais Y/UV são produzidos como storage inicializado e ligados via exact-initialized-storage. Portanto, esta etapa não altera Bink ownership, YUV cache, Wave64, MTBUF/D16 ou typed stores.

A auditoria do frontend RDNA2 encontrou uma divergência semântica concreta em operações cross-lane. `V_PERMLANE16_B32` e `V_PERMLANEX16_B32` sobrecarregam OP_SEL[0] como FI (Fetch Inactive) e OP_SEL[1] como BOUND_CTRL. O lowering anterior tratava FI, mas ignorava BOUND_CTRL: quando FI=0 e a lane fonte estava inativa, escrevia zero sempre. Em RDNA2, BOUND_CTRL=0 desabilita a escrita (preserva VDST), enquanto BOUND_CTRL=1 usa zero.

A mesma divergência existia no DPP16 genérico: BOUND_OFF + FI=0 ainda escrevia zero quando a lane fonte estava inativa, em vez de suprimir a escrita.

Shaders do caminho Bink observado usam `VPermlanex16B32` junto com sequências saveexec/EXEC, então essa diferença pode alterar diretamente dados intermediários de decode.

## Correção

- PERMLANE/PERMLANEX: implementa FI + BOUND_CTRL, preservando VDST quando BOUND_OFF deve desabilitar a escrita.
- DPP16: inclui atividade da lane fonte no write-enable quando FI=0 e BOUND_CTRL=0.
- Mantém DPP_BOUND_ZERO escrevendo zero e FI=1 permitindo fetch de lane inativa.
- Bump do cache SPIR-V de `V76.0.10-r1` para `V76.0.10-r2`, impedindo que shaders compilados com a semântica antiga sejam reutilizados do disco.

## Escopo

Altera exatamente dois arquivos:

- `src/SharpEmu.ShaderCompiler.Vulkan/Gen5SpirvTranslator.Alu.cs`
- `src/SharpEmu.Libs/Gpu/Vulkan/VulkanShaderBinaryCacheV7605.cs`

Nenhum decoder host, FFmpeg Bink, NihAV, RAD host, HLE Bink ou frame injection é adicionado.

## Hashes baseline -> final

- ALU: `ea8df89cb52ee9892a00a14f06d3a965bf0518781674af83940f0e0cadb009e8` -> `2ff2b1358d273c07ae1fa09f37977555d189f343a38c381c324e2d0c7592330a`
- Cache: `f1cff905d31904a870105aba7ae250f796089cd706a21a5f7a7da2d74f2354fe` -> `b342b86f60f9e4ef94ff25c9a554132aa6a74fe550faf84872a15170db42b87b`
- V76.0.10.3 main preservado: `81f81c1d897afbd03e86c6ad2223a6b3e742c57009a363df9ee6657e4f3f89b5`
- DS_SWIZZLE helper preservado: `99e575ffd9eab1e275dfa3ad548c5ec994a5f8e1172dfb693270ae4d808a81c1`
