param([string]$RepoRoot)
. (Join-Path $PSScriptRoot 'common.ps1')
& (Join-Path $PSScriptRoot 'validate.ps1')
$repo = Get-RepoRoot $RepoRoot
$state = Get-InstallState $repo
if ($state -ne 'Applied') { throw "SOURCE VERIFY FAILED state=$state" }
$translator = Join-Path $repo 'src\SharpEmu.ShaderCompiler\Gen5ShaderTranslator.cs'
$spirv = Join-Path $repo 'src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.cs'
$helper = Join-Path $repo $HelperRel
$checks = @(
    @{P=$translator; M='TBufferLoadFormatD16Xyzw'},
    @{P=$translator; M='BufferStoreFormatD16Xyzw'},
    @{P=$translator; M='ImageSampleCDO'},
    @{P=$spirv; M='NarrowGfx10FormatResultToD16'},
    @{P=$spirv; M='TryDecodeImageSampleOpcodeV7607'},
    @{P=$helper; M='EmitBufferFormatStoreV7608'}
)
foreach ($c in $checks) {
    if ([IO.File]::ReadAllText($c.P).IndexOf($c.M,[StringComparison]::Ordinal) -lt 0) { throw "marker ausente: $($c.M)" }
}
Write-Host "[$Tag] SOURCE VERIFY PASSED" -ForegroundColor Green
