$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$PackageRoot = Split-Path -Parent $PSScriptRoot
$Tag = 'V76.0.4.2-GFX10-MTBUF-D16-MIMG-TYPED-STORES'
$DefaultRepo = 'C:\Users\Edpo\Documents\GitHub\sharpemu'
$DefaultPatches = 'C:\Users\Edpo\Documents\GitHub\sharpemu\Patches'

$BeforeHashes = @{
    'src\SharpEmu.ShaderCompiler\Gen5ShaderIr.cs' = '533eea0914bd430fcb859e8677a612fe597e4e86a6e4ed90ad379996920c71cc'
    'src\SharpEmu.ShaderCompiler\Gen5ShaderTranslator.cs' = '8c8943c3de5d79a0cb9db32ab98753a28234d5ec37ba2070f60af64c5111d7a4'
    'src\SharpEmu.ShaderCompiler\Gen5ShaderScalarEvaluator.cs' = '41094f3d2dd92bcfe47cddc5f4ecbb9cddabc9cd0f54c68ec651410402991b54'
    'src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.cs' = 'ff475dc3f8d7ce31959145cc0463e7fb2614f1f6e17cd04073abceb564023881'
}
$AfterHashes = @{
    'src\SharpEmu.ShaderCompiler\Gen5ShaderIr.cs' = 'addd358c37ec7393bfeaaa9b0fa124236b5224d8fe0bb8d233cd3db52707b598'
    'src\SharpEmu.ShaderCompiler\Gen5ShaderTranslator.cs' = '6a416a4e818ebb2b82112d2c959d0027e4ebd39c9b8043c42b02ae13990350cb'
    'src\SharpEmu.ShaderCompiler\Gen5ShaderScalarEvaluator.cs' = '5d74a2d72520afc5228c2db958965c84ca63ad51013cc7f30070f6ff73bf3c66'
    'src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.cs' = 'fc98432a69848b158f2a7a8b17f40a0a32f571d3ea296290cc24e7afbc6ebf64'
    'src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.TypedBufferStoreV7608.cs' = 'c35c29220a7d534ee77136d4183c557b70069071b314ffeed2fa735e813a73c3'
}
$HelperRel = 'src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.TypedBufferStoreV7608.cs'
$HelperAfterHash = 'c35c29220a7d534ee77136d4183c557b70069071b314ffeed2fa735e813a73c3'
$AffectedExisting = @($BeforeHashes.Keys | Sort-Object)
$AffectedFinal = @($AfterHashes.Keys | Sort-Object)

function Get-Sha256([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-RepoRoot([string]$Requested) {
    if ([string]::IsNullOrWhiteSpace($Requested)) { $Requested = $DefaultRepo }
    $root = [IO.Path]::GetFullPath($Requested)
    if (-not (Test-Path -LiteralPath (Join-Path $root 'src\SharpEmu.CLI\SharpEmu.CLI.csproj') -PathType Leaf)) {
        throw "Repo root invalido: $root"
    }
    return $root
}

function Get-PatchesRoot([string]$Requested) {
    if ([string]::IsNullOrWhiteSpace($Requested)) { $Requested = $DefaultPatches }
    if (-not (Test-Path -LiteralPath $Requested)) { New-Item -ItemType Directory -Path $Requested -Force | Out-Null }
    return [IO.Path]::GetFullPath($Requested)
}

function Get-InstallState([string]$RepoRoot) {
    $beforeOk = $true
    foreach ($rel in $BeforeHashes.Keys) {
        if ((Get-Sha256 (Join-Path $RepoRoot $rel)) -ne $BeforeHashes[$rel]) { $beforeOk = $false; break }
    }
    $helperPath = Join-Path $RepoRoot $HelperRel
    $ready = $beforeOk -and -not (Test-Path -LiteralPath $helperPath)

    $afterOk = $true
    foreach ($rel in $AfterHashes.Keys) {
        if ((Get-Sha256 (Join-Path $RepoRoot $rel)) -ne $AfterHashes[$rel]) { $afterOk = $false; break }
    }
    if ($afterOk) { return 'Applied' }
    if ($ready) { return 'Ready' }
    return 'Divergent'
}

function Assert-ReadyOrApplied([string]$RepoRoot) {
    $state = Get-InstallState $RepoRoot
    if ($state -eq 'Divergent') {
        Write-Host "[$Tag] Source divergente. Hashes atuais:" -ForegroundColor Red
        foreach ($rel in $AffectedFinal) {
            $p = Join-Path $RepoRoot $rel
            Write-Host ("  {0} = {1}" -f $rel,(Get-Sha256 $p))
        }
        throw 'Baseline nao e V76.0.4.1 exata nem V76.0.4.2 ja aplicada.'
    }
    return $state
}
