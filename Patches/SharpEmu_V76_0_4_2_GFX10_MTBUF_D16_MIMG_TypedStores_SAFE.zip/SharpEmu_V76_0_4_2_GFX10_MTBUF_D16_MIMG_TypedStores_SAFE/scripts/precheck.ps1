param([string]$RepoRoot)
. (Join-Path $PSScriptRoot 'common.ps1')
& (Join-Path $PSScriptRoot 'validate.ps1')
$repo = Get-RepoRoot $RepoRoot
$state = Assert-ReadyOrApplied $repo
Write-Host "[$Tag] PRECHECK PASSED state=$state repo=$repo" -ForegroundColor Green
if ($state -eq 'Ready') {
    foreach ($rel in $AffectedExisting) { Write-Host ("  BEFORE {0} {1}" -f $BeforeHashes[$rel],$rel) }
}
