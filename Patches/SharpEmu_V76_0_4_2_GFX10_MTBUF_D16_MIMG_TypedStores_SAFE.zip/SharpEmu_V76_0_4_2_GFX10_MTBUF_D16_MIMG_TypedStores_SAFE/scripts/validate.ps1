param()
. (Join-Path $PSScriptRoot 'common.ps1')
$manifest = Join-Path $PackageRoot 'manifest.sha256'
if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'manifest.sha256 ausente' }
$lines = Get-Content -LiteralPath $manifest | Where-Object { $_.Trim().Length -gt 0 }
foreach ($line in $lines) {
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+\*(.+)$') { throw "manifest invalido: $line" }
    $expected = $Matches[1].ToLowerInvariant()
    $relative = $Matches[2].Replace('/','\')
    $path = Join-Path $PackageRoot $relative
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "arquivo do manifest ausente: $relative" }
    $actual = Get-Sha256 $path
    if ($actual -ne $expected) { throw "hash invalido: $relative expected=$expected actual=$actual" }
}
# Package must remain offline/self-contained.
$bad = @()
Get-ChildItem -LiteralPath $PackageRoot -Recurse -File -Include *.ps1,*.cmd | Where-Object { $_.FullName -ne $PSCommandPath } | ForEach-Object {
    $text = [IO.File]::ReadAllText($_.FullName)
    if ($text -match '(?i)Invoke-WebRequest|Invoke-RestMethod|Start-BitsTransfer|curl\.exe|wget\.exe') { $bad += $_.FullName }
}
if ($bad.Count -ne 0) { throw "network downloader encontrado: $($bad -join ', ')" }
Write-Host "[$Tag] PACKAGE VALIDATION PASSED entries=$($lines.Count) offline=PASS" -ForegroundColor Green
