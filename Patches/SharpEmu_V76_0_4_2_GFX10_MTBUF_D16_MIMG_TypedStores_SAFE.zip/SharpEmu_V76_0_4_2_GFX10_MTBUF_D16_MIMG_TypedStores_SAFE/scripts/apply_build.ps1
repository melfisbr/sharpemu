param([string]$RepoRoot,[string]$PatchesRoot)
. (Join-Path $PSScriptRoot 'common.ps1')
& (Join-Path $PSScriptRoot 'validate.ps1')
$repo = Get-RepoRoot $RepoRoot
$patches = Get-PatchesRoot $PatchesRoot
$state = Assert-ReadyOrApplied $repo
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$buildLog = Join-Path $patches ("SharpEmu_V76_0_4_2_BUILD_{0}.log" -f $stamp)
$summary = Join-Path $patches ("SharpEmu_V76_0_4_2_SUMMARY_{0}.txt" -f $stamp)
$result = Join-Path $patches ("SharpEmu_V76_0_4_2_RESULT_{0}.zip" -f $stamp)
$backup = Join-Path $patches ("SharpEmu_V76_0_4_2_PREVIOUS_FILES_{0}.zip" -f $stamp)
$stage = Join-Path $env:TEMP ("SharpEmu_V76_0_4_2_{0}" -f $stamp)
$backupStage = Join-Path $stage 'backup'
$resultStage = Join-Path $stage 'result'
New-Item -ItemType Directory -Path $backupStage,$resultStage -Force | Out-Null

if ($state -eq 'Applied') {
    Write-Host "[$Tag] Already applied; build/verify only." -ForegroundColor Yellow
} else {
    foreach ($rel in $AffectedExisting) {
        $src = Join-Path $repo $rel
        $dst = Join-Path $backupStage $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
        Copy-Item -LiteralPath $src -Destination $dst -Force
    }
    Compress-Archive -Path (Join-Path $backupStage '*') -DestinationPath $backup -CompressionLevel Fastest -Force
    Write-Host "[$Tag] Backup=$backup"
    foreach ($rel in $AffectedFinal) {
        $payload = Join-Path (Join-Path $PackageRoot 'payload') $rel
        $dst = Join-Path $repo $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
        Copy-Item -LiteralPath $payload -Destination $dst -Force
    }
}

$postState = Get-InstallState $repo
if ($postState -ne 'Applied') { throw "Post-apply hash verify falhou state=$postState" }

Push-Location $repo
try {
    $output = & dotnet build '.\src\SharpEmu.CLI\SharpEmu.CLI.csproj' -c Debug 2>&1
    $exit = $LASTEXITCODE
    $output | Tee-Object -FilePath $buildLog
} finally { Pop-Location }

if ($exit -ne 0) {
    if ($state -eq 'Ready') {
        Write-Host "[$Tag] BUILD FAILED; restoring baseline..." -ForegroundColor Red
        foreach ($rel in $AffectedExisting) {
            $src = Join-Path $backupStage $rel
            $dst = Join-Path $repo $rel
            Copy-Item -LiteralPath $src -Destination $dst -Force
        }
        $helper = Join-Path $repo $HelperRel
        if (Test-Path -LiteralPath $helper) { Remove-Item -LiteralPath $helper -Force }
    }
    throw "V76.0.4.2 BUILD FAILED exit_code=$exit log=$buildLog"
}

$lines = @(
    'SharpEmu V76.0.4.2 GFX10 MTBUF D16 MIMG Typed Stores',
    "Timestamp=$stamp",
    "Repository=$repo",
    "InitialState=$state",
    'Build=PASSED',
    'SourceVerify=PASSED',
    'BinkOwnership=guest',
    'HostDecoderAdded=false',
    'MTBUF4BitOpcode=true',
    'MTBUFInstructionFormat=true',
    'MTBUFD16Packed=true',
    'MUBUF8BitOpcode=true',
    'MUBUFFORMATD16=true',
    'TypedStores=true',
    'MIMGNonMinLodCoverage=true',
    "BuildLog=$buildLog",
    "Backup=$backup",
    "Result=$result"
)
$lines | Set-Content -LiteralPath $summary -Encoding UTF8

foreach ($rel in $AffectedFinal) {
    $src = Join-Path $repo $rel
    $dst = Join-Path $resultStage $rel
    New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
}
Copy-Item -LiteralPath $summary -Destination (Join-Path $resultStage (Split-Path -Leaf $summary)) -Force
Copy-Item -LiteralPath $buildLog -Destination (Join-Path $resultStage (Split-Path -Leaf $buildLog)) -Force
Compress-Archive -Path (Join-Path $resultStage '*') -DestinationPath $result -CompressionLevel Fastest -Force
Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[$Tag] BUILD PASSED" -ForegroundColor Green
Write-Host "[$Tag] Summary=$summary"
Write-Host "[$Tag] Result=$result"
