# V76.0.4.2

- Corrige alias silencioso de MTBUF D16 causado por opcode GFX10 truncado a 3 bits.
- Propaga FORMAT MTBUF da instrução e quantidade lógica de componentes separada de VGPRs D16 packed.
- Corrige MUBUF opcode width para 8 bits e a família FORMAT_D16.
- Implementa typed format stores MTBUF/MUBUF em vez de gravar dwords crus.
- Amplia MIMG SAMPLE não-MinLod suportável pelo lowering atual.
- Preserva integralmente guest-owned Bink e V76.0.4.1 Wave64.
