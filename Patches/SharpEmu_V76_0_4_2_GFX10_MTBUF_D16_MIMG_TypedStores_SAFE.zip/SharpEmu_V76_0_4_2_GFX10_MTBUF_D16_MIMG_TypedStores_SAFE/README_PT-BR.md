# SharpEmu V76.0.4.2 — GFX10 MTBUF D16 / MIMG / Typed Stores SAFE

Baseline obrigatório: **V76.0.4.1 OFW/RDNA2 Per-Wave64 BuildFix** desta sequência.

Esta correção mantém Bink2 100% guest-owned. Não adiciona RAD, FFmpeg, NihAV ou HLE Bink.

## Motivo
O runtime V76.0.4.1 confirmou que o bridge Wave64 multi-wave está ativo e que os planos finais Y/UV chegam como `exact-initialized-storage`, mas a corrupção verde/magenta permanece.

No frontend GFX10 foi encontrado um erro silencioso e determinístico: `DecodeMtbuf` lia somente `OP[2:0]`. Em GFX10, MTBUF usa opcode de 4 bits: `OP[2:0]` em word[18:16] e `OP[3]` em bit 53 (bit 21 do segundo dword). Assim, toda a família D16 0x8..0xF era aliasada para 0x0..0x7, podendo compilar com sucesso e produzir valores errados.

## Implementado
- MTBUF GFX10 opcode completo de 4 bits.
- `TBUFFER_LOAD_FORMAT_D16_X/XY/XYZ/XYZW`.
- `TBUFFER_STORE_FORMAT_D16_X/XY/XYZ/XYZW`.
- FORMAT MTBUF vem da própria instrução (word[25:19]), sem usar FORMAT/dst_sel do SRD.
- D16 packed: pares de componentes de 16 bits por VGPR.
- MUBUF opcode completo de 8 bits e `BUFFER_*_FORMAT_D16` 0x80..0x87.
- Typed stores reais para MTBUF e MUBUF com conversão UNORM/SNORM/scaled/UINT/SINT/f16/f32/UFLOAT 10/11-bit.
- Ampliação da família MIMG SAMPLE não-MinLod e parsing semântico de compare/gradient/LOD/bias/offset.
- Formas `*_Cl` continuam explicitamente não mascaradas até suporte MinLod correto.

## Segurança
- PRECHECK exige hashes exatos da V76.0.4.1 nos quatro arquivos existentes e ausência do novo helper.
- Backup ZIP antes do primeiro write.
- Falha de build restaura os quatro arquivos e remove o helper novo.
- Logs, SUMMARY e RESULT ZIP são gravados diretamente em `C:\Users\Edpo\Documents\GitHub\sharpemu\Patches`.
