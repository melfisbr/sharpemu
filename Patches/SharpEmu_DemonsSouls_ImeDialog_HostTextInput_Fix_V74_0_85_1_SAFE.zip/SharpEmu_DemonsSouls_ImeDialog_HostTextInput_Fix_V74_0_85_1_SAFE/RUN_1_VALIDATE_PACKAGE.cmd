@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\validate.ps1"
exit /b %errorlevel%
