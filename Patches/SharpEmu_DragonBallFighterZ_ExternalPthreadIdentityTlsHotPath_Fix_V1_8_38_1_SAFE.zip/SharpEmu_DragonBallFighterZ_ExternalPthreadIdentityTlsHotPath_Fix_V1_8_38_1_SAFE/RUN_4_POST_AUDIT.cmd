@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run_logged.ps1" -Mode PostAudit
exit /b %ERRORLEVEL%
