V76.3.21.3 - Guest Progress Recovery + Performance Merge DEV SAFE
=================================================================

Este e o pacote CORRIGIDO. O V21.3 anterior preservava por engano chain8/draw32/microbatch64.
Este pacote realmente sobrescreve o perfil agressivo V21.1 depois dele com o envelope:

work/render       1024
producer scan      512
closure age        300 ms
closure slices       8
closure budget     128
slice pause       1000 us
ordered microbatch  32
compute chain         4
draw command buffer   8
wait fullscan        16 ms
producer headroom    48

Nao substitui nem edita VulkanVideoPresenter.cs, AgcExports.cs ou DirectExecutionBackend.cs.
O PRECHECK exige V21.2 snapshot bounds, V21.1 producer-query depth e guest progress recovery existentes.

Marker esperado:
[V76.3.21.3][GUEST_PROGRESS_RECOVERY] mode=conservative-progress work_per_render=1024 producer_query=256/1024 producer_scan=512 closure=300ms/8x128/1000us microbatch=32 compute_chain=4 draw_cb=8 wait_fullscan=16ms producer_headroom=48 dual_queue=preserved async_agc=preserved snapshot_v212=preserved residency=preserved bink=natural-request-only auto_boot=off

Execucao:
1. RUN_1_VALIDATE_PACKAGE.cmd
2. RUN_2_PRECHECK.cmd
3. RUN_3_APPLY_BUILD.cmd
4. RUN_4_DIAGNOSTIC.cmd
5. RUN_5_ROLLBACK_LAST.cmd somente se desejar desfazer manualmente.

RUN_3: Debug/win-x64, Optimize=true, TieredPGO=true, backup antes da mutacao e rollback automatico em falha.
RUN_4: maximo 210s; encerra 15s depois de observar a requisicao natural de ps_studios_logo.bk2.

O diagnostico nao liga BINK_AUTO_BOOT. Ele prearma SHARPEMU_BINK_AUTO_BOOT=0 e procura:
[BINK-HOST][...][NATURAL-REQUEST] file='ps_studios_logo.bk2'
ou
bink2.natural_guest_movie_observed ... file='ps_studios_logo.bk2'
