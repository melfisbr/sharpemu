﻿param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$tag = 'V76.3.21.3-GUEST-PROGRESS-RECOVERY-PERF-MERGE-DEV-SAFE'
$manifest = Join-Path $root 'PACKAGE_SHA256.txt'
if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
    throw "[$tag] PACKAGE_SHA256.txt ausente"
}

$lines = @(Get-Content -LiteralPath $manifest | Where-Object { $_.Trim() })
foreach ($line in $lines) {
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+(.+)$') {
        throw "[$tag] manifest line invalida: $line"
    }
    $expected = $Matches[1].ToLowerInvariant()
    $rel = $Matches[2]
    $path = Join-Path $root $rel
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "[$tag] arquivo do manifest ausente: $rel"
    }
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected) {
        throw "[$tag] hash divergente: $rel expected=$expected actual=$actual"
    }
}

$scripts = Get-ChildItem -LiteralPath (Join-Path $root 'scripts') -Filter '*.ps1' -File
foreach ($s in $scripts) {
    $text = [IO.File]::ReadAllText($s.FullName)
    if ($text -match '(?i)Invoke-WebRequest|Start-BitsTransfer|\bcurl(?:\.exe)?\b|\bwget(?:\.exe)?\b') {
        throw "[$tag] downloader direto proibido: $($s.Name)"
    }
    if ($text -match '(?mi)^\s*\$Host\s*=') {
        throw "[$tag] read-only automatic variable assignment: $($s.Name):`$Host"
    }
}

$apply = [IO.File]::ReadAllText((Join-Path $root 'scripts\apply_build.ps1'))
foreach ($required in @(
    'SHARPEMU_MAX_GUEST_WORK_PER_RENDER", "1024',
    'SHARPEMU_FIFO_WATCHED_PRODUCER_SCAN_DEPTH", "512',
    'SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_AGE_MS", "300',
    'SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_MAX_SLICES", "8',
    'SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SLICE_PAUSE_US", "1000',
    'SHARPEMU_ORDERED_ACTION_MICROBATCH_MAX", "32',
    'SHARPEMU_COMPUTE_CHAIN_MAX_V763171", "4',
    'SHARPEMU_DRAW_COMMAND_BUFFER_MAX", "8',
    'SHARPEMU_WAIT_FULL_SCAN_MIN_MS", "16',
    'SHARPEMU_PENDING_GUEST_WORK_PRODUCER_ITEMS", "48',
    'SHARPEMU_BINK_AUTO_BOOT", "0'
)) {
    if (-not $apply.Contains($required)) {
        throw "[$tag] parameter contract ausente: $required"
    }
}

Write-Host "[$tag] VALIDATE PASSED files=$($lines.Count) scripts=$($scripts.Count) cli_only=1"
