﻿param()
. (Join-Path $PSScriptRoot 'common.ps1')
Ensure-Repo

$exe = Join-Path $Repo 'artifacts\bin\Debug\net10.0\win-x64\SharpEmu.exe'
$game = 'F:\JOGOSPS5\PPSA01341\eboot.bin'
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { Fail "Debug exe ausente: $exe" }
if (-not (Test-Path -LiteralPath $game -PathType Leaf)) { Fail "eboot ausente: $game" }

Get-Process SharpEmu -ErrorAction SilentlyContinue |
    Stop-Process -Force -ErrorAction SilentlyContinue

# Diagnostic policy: natural guest request only; never fake startup with auto-boot.
$env:SHARPEMU_BINK_AUTO_BOOT = '0'
Remove-Item Env:\SHARPEMU_BINK_BOOT_SEQUENCE -ErrorAction SilentlyContinue
$env:SHARPEMU_PROFILE_RENDER = '1'
$env:SHARPEMU_PROFILE_ORDERED_ACTION = '1'
$env:SHARPEMU_PROFILE_RENDER_REPORT_S = '5'
$env:SHARPEMU_TRACE_FRAME_STATS = '1'

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$stdout = Join-Path $Patches "V76.3.21.3_STDOUT_$stamp.log"
$stderr = Join-Path $Patches "V76.3.21.3_STDERR_$stamp.log"
$summary = Join-Path $Patches "V76.3.21.3_SUMMARY_$stamp.txt"
$nvidia = Join-Path $Patches "V76.3.21.3_NVIDIA_$stamp.csv"
$result = Join-Path $Patches "V76.3.21.3_RESULT_$stamp.zip"

"sample,time,gpu_util_pct,vram_used_mb,power_w" |
    Set-Content -LiteralPath $nvidia -Encoding UTF8

$start = Get-Date
$p = Start-Process -FilePath $exe -ArgumentList @($game) -PassThru `
    -RedirectStandardOutput $stdout -RedirectStandardError $stderr

$deadline = $start.AddSeconds(210)
$nextNvidia = Get-Date
$sample = 0
$naturalSeenAt = $null

while (-not $p.HasExited -and (Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 500

    if (-not $naturalSeenAt -and (Test-Path -LiteralPath $stderr)) {
        $naturalNow = Select-String -LiteralPath $stderr `
            -Pattern "NATURAL-REQUEST.*file='ps_studios_logo\.bk2'|natural_guest_movie_observed.*file='ps_studios_logo\.bk2'" `
            -Quiet -ErrorAction SilentlyContinue
        if ($naturalNow) { $naturalSeenAt = Get-Date }
    }

    # Once the real guest request is proven, keep 15 seconds of post-proof data.
    if ($naturalSeenAt -and (Get-Date) -ge $naturalSeenAt.AddSeconds(15)) {
        break
    }

    if ((Get-Date) -ge $nextNvidia) {
        $smi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
        if ($smi) {
            try {
                $row = & $smi.Source `
                    --query-gpu=utilization.gpu,memory.used,power.draw `
                    --format=csv,noheader,nounits 2>$null | Select-Object -First 1
                if ($row) {
                    "$sample,$((Get-Date).ToString('o')),$row" |
                        Add-Content -LiteralPath $nvidia -Encoding UTF8
                }
            } catch {}
        }
        $sample++
        $nextNvidia = (Get-Date).AddSeconds(5)
    }
}

$exitCode = ''
if (-not $p.HasExited) {
    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
    try { $p.WaitForExit() } catch {}
}
else {
    try { $p.WaitForExit(); $exitCode = $p.ExitCode } catch {}
}

$out = if (Test-Path -LiteralPath $stdout) {
    @(Get-Content -LiteralPath $stdout -ErrorAction SilentlyContinue)
} else { @() }
$err = if (Test-Path -LiteralPath $stderr) {
    @(Get-Content -LiteralPath $stderr -ErrorAction SilentlyContinue)
} else { @() }

function Get-MaxLong([object[]]$Lines,[string]$Pattern) {
    $max = 0L
    foreach ($line in $Lines) {
        $m = [regex]::Match($line, $Pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($m.Success) {
            $v = 0L
            if ([long]::TryParse($m.Groups[1].Value, [ref]$v) -and $v -gt $max) { $max = $v }
        }
    }
    return $max
}

$profile = @($err | Where-Object { $_ -match '\[V76\.3\.21\.3\]\[GUEST_PROGRESS_RECOVERY\]' })
$main = @($out | Where-Object { $_ -match 'Starting main loop:' }).Count -gt 0
$first = @($err | Where-Object { $_ -match 'Vulkan VideoOut presented first frame' }).Count -gt 0
$naturalLines = @($err | Where-Object {
    $_ -match "NATURAL-REQUEST.*file='ps_studios_logo\.bk2'|natural_guest_movie_observed.*file='ps_studios_logo\.bk2'"
})
$naturalPs = $naturalLines.Count -gt 0

$agcEnqueue = @($err | Where-Object { $_ -match '\[V76\.3\.17\.0\]\[AGC_ASYNC_CP\].*phase=enqueue' })
$agcProcessed = @($err | Where-Object { $_ -match '\[V76\.3\.17\.0\]\[AGC_ASYNC_CP\].*phase=processed' })
$graphics = @($err | Where-Object { $_ -match 'queue=dcb\.graphics.*submission=\d+' })
$scanout = @($err | Where-Object { $_ -match '\[DIRECT_SCANOUT\].*frame_count=\d+' })
$asyncFault = @($err | Where-Object { $_ -match '\[V76\.3\.17\.0\]\[AGC_ASYNC_CP_FAULT\]' })
$device = @($err | Where-Object { $_ -match 'VK_ERROR_DEVICE_LOST|Result\.ErrorDeviceLost|deviceLost=True|\[DEVICE_LOST\]' })
$av = @($err | Where-Object { $_ -match 'AccessViolationException|0xC0000005|ACCESS_VIOLATION' })
$fatal = @($err | Where-Object { $_ -match 'Fatal error\.|FailFast|Unhandled exception|SEHException' })
$slow = @($err | Where-Object { $_ -match 'SLOW_WAIT_PRODUCER' })
$perf = @($err | Where-Object { $_ -match '\[PERF\]\[RENDER\]' })
$closure = @($err | Where-Object { $_ -match 'WEIGHTED_PRODUCER_CLOSURE' })
$nativeProgress = @($err | Where-Object { $_ -match 'native guest execution is advancing' })

$maxAgcEnqueue = Get-MaxLong $agcEnqueue 'count=(\d+)'
$maxAgcProcessed = Get-MaxLong $agcProcessed 'count=(\d+)'
$maxDrawSubmission = Get-MaxLong $graphics 'queue=dcb\.graphics.*submission=(\d+)'
$maxDirectScanoutFrame = Get-MaxLong $scanout 'frame_count=(\d+)'

$agcBeyond = $maxAgcProcessed -gt 1024
$drawBeyond = $maxDrawSubmission -gt 1181
$scanoutBeyond = $maxDirectScanoutFrame -gt 44
$progressBeyondV212 = $agcBeyond -or $drawBeyond -or $scanoutBeyond
$recovered = $naturalPs

$gpuValues = @(); $vramValues = @(); $powerValues = @()
if (Test-Path -LiteralPath $nvidia) {
    foreach ($line in @(Get-Content -LiteralPath $nvidia | Select-Object -Skip 1)) {
        $parts = $line -split ','
        if ($parts.Count -ge 5) {
            $v = 0.0
            if ([double]::TryParse($parts[2].Trim(),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$v)) { $gpuValues += $v }
            if ([double]::TryParse($parts[3].Trim(),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$v)) { $vramValues += $v }
            if ([double]::TryParse($parts[4].Trim(),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$v)) { $powerValues += $v }
        }
    }
}
function Avg0($Values) { if ($Values.Count) { return ($Values | Measure-Object -Average).Average }; return 0 }
function Max0($Values) { if ($Values.Count) { return ($Values | Measure-Object -Maximum).Maximum }; return 0 }

@(
    'tag=V76.3.21.3-GUEST-PROGRESS-RECOVERY-PERF-MERGE-DEV-SAFE',
    "runtime_seconds=$([Math]::Round(((Get-Date)-$start).TotalSeconds,3))",
    "exit_code=$exitCode",
    "main_loop_detected=$main",
    "first_frame_detected=$first",
    "natural_ps_studios_request=$naturalPs",
    "guest_progress_recovered=$recovered",
    "progress_beyond_v212=$progressBeyondV212",
    "max_agc_enqueue_count=$maxAgcEnqueue",
    "max_agc_processed_count=$maxAgcProcessed",
    "max_draw_submission=$maxDrawSubmission",
    "max_direct_scanout_frame=$maxDirectScanoutFrame",
    "agc_processed_gt_1024=$agcBeyond",
    "draw_submission_gt_1181=$drawBeyond",
    "direct_scanout_gt_44=$scanoutBeyond",
    "async_cp_faults=$($asyncFault.Count)",
    "native_progress_recovery_lines=$($nativeProgress.Count)",
    "device_lost_markers=$($device.Count)",
    "access_violation_markers=$($av.Count)",
    "fatal_markers=$($fatal.Count)",
    "nvidia_samples=$($gpuValues.Count)",
    "nvidia_gpu_util_avg=$([Math]::Round((Avg0 $gpuValues),2))",
    "nvidia_gpu_util_max=$([Math]::Round((Max0 $gpuValues),2))",
    "nvidia_vram_used_max_mb=$([Math]::Round((Max0 $vramValues),1))",
    "nvidia_power_max_w=$([Math]::Round((Max0 $powerValues),2))",
    '',
    '--- ACTIVE V21.3 PROFILE ---', $profile,
    '',
    '--- NATURAL PS STUDIOS REQUEST ---', $naturalLines,
    '',
    '--- AGC ASYNC LAST ---', (($agcEnqueue + $agcProcessed) | Select-Object -Last 64),
    '',
    '--- GRAPHICS PROGRESS LAST ---', ($graphics | Select-Object -Last 64),
    '',
    '--- DIRECT SCANOUT LAST ---', ($scanout | Select-Object -Last 32),
    '',
    '--- PRODUCER CLOSURE LAST ---', ($closure | Select-Object -Last 64),
    '',
    '--- SLOW WAIT LAST ---', ($slow | Select-Object -Last 32),
    '',
    '--- PERF LAST ---', ($perf | Select-Object -Last 32),
    '',
    '--- DEVICE LOST ---', $device,
    '',
    '--- ACCESS VIOLATION ---', $av,
    '',
    '--- FATAL ---', $fatal
) | Set-Content -LiteralPath $summary -Encoding UTF8

$files = @($stdout,$stderr,$nvidia,$summary) | Where-Object { Test-Path -LiteralPath $_ }
Compress-Archive -LiteralPath $files -DestinationPath $result -CompressionLevel Optimal -Force

Write-Host "[$Tag] DIAGNOSTIC COMPLETE"
Write-Host (
    "[$Tag] natural_ps_studios=$naturalPs agc=$maxAgcProcessed " +
    "draw_submission=$maxDrawSubmission scanout=$maxDirectScanoutFrame"
)
Write-Host (
    "[$Tag] device=$($device.Count) av=$($av.Count) fatal=$($fatal.Count) result=$result"
)
