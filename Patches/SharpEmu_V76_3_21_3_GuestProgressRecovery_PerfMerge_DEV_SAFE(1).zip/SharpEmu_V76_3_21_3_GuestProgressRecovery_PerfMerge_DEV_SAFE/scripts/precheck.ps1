﻿param()
. (Join-Path $PSScriptRoot 'common.ps1')
Ensure-Repo

$cli = [IO.File]::ReadAllText($CliPath)
$presenter = [IO.File]::ReadAllText($PresenterPath)
$agc = [IO.File]::ReadAllText($AgcPath)
$backend = [IO.File]::ReadAllText($BackendPath)

foreach ($m in @(
    '[V76.3.21.1][MAX_CRITICAL_PATH_MERGE]',
    '[V76.3.21.2][GLOBAL_SNAPSHOT_BOUNDS]',
    'Set("SHARPEMU_AGC_ASYNC_COMMAND_PROCESSOR", "1");',
    'Set("SHARPEMU_HOST_ONLY_SIDEBAND", "0");',
    'Set("SHARPEMU_DS_SAFE_MEMCOPY_V763151", "1");'
)) {
    if (-not $cli.Contains($m)) {
        Fail "CLI baseline V21.1/V21.2 ausente: $m"
    }
}

foreach ($m in @(
    'V76.3.21.2_GLOBAL_SNAPSHOT_BOUNDS',
    'partialSnapshotV763212',
    '[V76.3.21.2][GLOBAL_SNAPSHOT_REPAIR]'
)) {
    if (-not $presenter.Contains($m)) {
        Fail "Presenter V21.2 snapshot contract ausente: $m"
    }
}

foreach ($m in @(
    'V76.3.21.1_PLANNED_PRODUCER_QUERY_DEPTH',
    'SHARPEMU_PLANNED_PRODUCER_QUERY_SCAN',
    'SHARPEMU_AGED_PRODUCER_QUERY_SCAN',
    'probe < _plannedProducerQueryScanV763211',
    'probe < _agedProducerQueryScanV763211'
)) {
    if (-not $agc.Contains($m)) {
        Fail "AGC V21.1 producer-query contract ausente: $m"
    }
}

foreach ($m in @(
    'StartReadyThreadDispatcher()',
    'StopReadyThreadDispatcher()',
    'DispatchReadyGuestThreads();',
    'HasNativeGuestExecutionProgress(out string detail)',
    '_entryHostThreadId'
)) {
    if (-not $backend.Contains($m)) {
        Fail "guest progress recovery contract ausente: $m"
    }
}

$dotnet = (Get-Command dotnet.exe -ErrorAction SilentlyContinue).Source
if (-not $dotnet) {
    $dotnet = (Get-Command dotnet -ErrorAction SilentlyContinue).Source
}
if (-not $dotnet) { Fail 'dotnet nao encontrado' }

$oldBad = $cli.Contains('[V76.3.21.3][GUEST_PROGRESS_PERF_MERGE]')
$already = $cli.Contains('[V76.3.21.3][GUEST_PROGRESS_RECOVERY]')

Write-Host (
    "[$Tag] PRECHECK PASSED " +
    "V21.2_snapshot=1 V21.1_query_depth=1 guest_progress=1 " +
    "old_bad_marker=$([int]$oldBad) already_correct=$([int]$already) " +
    "cli_sha256=$(Get-HashLower $CliPath)"
)
