﻿param()
. (Join-Path $PSScriptRoot 'common.ps1')
Ensure-Repo
& (Join-Path $PSScriptRoot 'precheck.ps1')

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupRoot = Join-Path $Patches ("V76_3_21_3_PRE_SOURCE_$stamp")
$backupZip = Join-Path $Patches ("V76_3_21_3_PRE_SOURCE_$stamp.zip")
$restoreLog = Join-Path $Patches ("V76_3_21_3_DEV_RESTORE_$stamp.log")
$buildLog = Join-Path $Patches ("V76_3_21_3_DEV_BUILD_$stamp.log")

$backupCli = Join-Path $backupRoot $CliRel
New-Item -ItemType Directory -Force -Path (Split-Path $backupCli -Parent) | Out-Null
Copy-Item -LiteralPath $CliPath -Destination $backupCli -Force
Compress-Archive -Path (Join-Path $backupRoot '*') -DestinationPath $backupZip -CompressionLevel Optimal -Force

function Restore-Source {
    Copy-Item -LiteralPath $backupCli -Destination $CliPath -Force
}

try {
    $c = Read-Utf8Preserve $CliPath
    $t = $c.Text
    $nl = if ($t.Contains("`r`n")) { "`r`n" } else { "`n" }

    # Remove only the logging-only V21.3 marker from the previously generated
    # incorrect package, if the user happened to apply it. It carried no policy.
    $t = Remove-ConsoleMarkerStatement `
        $t `
        '[V76.3.21.3][GUEST_PROGRESS_PERF_MERGE]'

    $begin = '        // V76.3.21.3_GUEST_PROGRESS_RECOVERY_PROFILE_BEGIN'
    $end = '        // V76.3.21.3_GUEST_PROGRESS_RECOVERY_PROFILE_END'

    $block = @(
        '        // V76.3.21.3_GUEST_PROGRESS_RECOVERY_PROFILE_BEGIN',
        '        // Conservative progress envelope applied AFTER V21.1. It keeps',
        '        // the V21.2 snapshot fix, real dual queues, Async AGC, residency',
        '        // and hazard/timeline correctness while returning scheduler',
        '        // monopolization controls to the proven progress-oriented range.',
        '        var disableV763213 = string.Equals(',
        '            Environment.GetEnvironmentVariable("SHARPEMU_V763213_DISABLE"),',
        '            "1",',
        '            StringComparison.Ordinal);',
        '',
        '        if (!disableV763213)',
        '        {',
        '            // Balanced feed stays unchanged.',
        '            Set("SHARPEMU_PENDING_GUEST_WORK_ITEMS", "192");',
        '            Set("SHARPEMU_PENDING_GUEST_WORK_MB", "96");',
        '            Set("SHARPEMU_KYTY_QUEUE_SUBMISSION_BURST", "4");',
        '            Set("SHARPEMU_RESERVED_HOST_LANES", "6");',
        '            Set("SHARPEMU_MAX_INFLIGHT_GUEST_SUBMISSIONS", "16");',
        '            Set("SHARPEMU_PENDING_GUEST_WORK_PRODUCER_ITEMS", "48");',
        '',
        '            // V21.1 read-only producer discovery is preserved. Only the',
        '            // queue/closure scheduling depth returns to the proven 512.',
        '            Set("SHARPEMU_PLANNED_PRODUCER_QUERY_SCAN", "256");',
        '            Set("SHARPEMU_AGED_PRODUCER_QUERY_SCAN", "1024");',
        '            Set("SHARPEMU_FIFO_WATCHED_PRODUCER_ASSIST", "1");',
        '            Set("SHARPEMU_FIFO_WATCHED_PRODUCER_SCAN_DEPTH", "512");',
        '            Set("SHARPEMU_PLANNED_PRODUCER_QUEUE_PRIORITY", "1");',
        '',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE", "1");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_AGE_MS", "300");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_MAX_ITEMS", "128");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_LIFETIME_MS", "5000");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SYNC_SCAN", "512");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SLICES", "1");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_MAX_SLICES", "8");',
        '            Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SLICE_PAUSE_US", "1000");',
        '',
        '            // Restore bounded event-first wait recovery.',
        '            Set("SHARPEMU_WAIT_FULL_SCAN_MIN_MS", "16");',
        '            Set("SHARPEMU_DEDICATED_WAIT_DRAIN", "1");',
        '            Set("SHARPEMU_AGC_DEDICATED_FAST_ONLY", "1");',
        '            Set("SHARPEMU_AGC_SUBMIT_EVIDENCE_WAIT_DRAIN", "1");',
        '            Set("SHARPEMU_UPSTREAM003_DIRECT_DRAIN", "1");',
        '            Set("SHARPEMU_WATCHED_WRITE_DATA_PACKET_POSITION", "1");',
        '            Set("SHARPEMU_SKIP_KNOWN_PRODUCER_WAIT_VISIBILITY", "1");',
        '            Set("SHARPEMU_KYTY_PM4_BLOCKED_SCHEDULER", "1");',
        '            Set("SHARPEMU_KYTY_INLINE_WRITE_DATA", "1");',
        '',
        '            // Yield capacity back to guest producers.',
        '            Set("SHARPEMU_MAX_GUEST_WORK_PER_RENDER", "1024");',
        '            Set("SHARPEMU_COMPUTE_CHAIN_MAX_V763171", "4");',
        '            Set("SHARPEMU_DRAW_COMMAND_BUFFER", "1");',
        '            Set("SHARPEMU_DRAW_COMMAND_BUFFER_MAX", "8");',
        '            Set("SHARPEMU_PRESERVE_PAYLOAD_BATCH", "1");',
        '            Set("SHARPEMU_ORDERED_ACTION_MICROBATCH", "1");',
        '            Set("SHARPEMU_ORDERED_ACTION_MICROBATCH_MAX", "32");',
        '            Set("SHARPEMU_FIFO_PAYLOAD_TRAIN_MAX", "1");',
        '            Set("SHARPEMU_HOST_ONLY_SIDEBAND", "0");',
        '            Set("SHARPEMU_WATCHED_WRITE_CONTROL_LANE", "0");',
        '            Set("SHARPEMU_SYNC_PRIORITY_REAL_WAIT_ONLY", "1");',
        '            Set("SHARPEMU_DISJOINT_COMPUTE_PAIR2", "1");',
        '',
        '            // Preserve real graphics/compute Vulkan lanes and exact hazards.',
        '            Set("SHARPEMU_DUAL_PHYSICAL_QUEUE", "1");',
        '            Set("SHARPEMU_DUAL_QUEUE_RESOURCE_SYNC", "1");',
        '            Set("SHARPEMU_DUAL_QUEUE_SYNC_POLICY", "resource");',
        '            Set("SHARPEMU_BINK_STRICT_RESOURCE_SCOPE", "1");',
        '',
        '            // Preserve the dedicated asynchronous AGC processor.',
        '            Set("SHARPEMU_AGC_ASYNC_COMMAND_PROCESSOR", "1");',
        '            Set("SHARPEMU_AGC_ASYNC_CP_MAX_INGRESS", "1024");',
        '',
        '            // Keep V21 residency/cache requests and memory safety.',
        '            Set("SHARPEMU_GPU_RESIDENT_SHADER_V1180", "1");',
        '            Set("SHARPEMU_GPU_RESIDENT_SHADER_MAX_V1180", "2048");',
        '            Set("SHARPEMU_DESCRIPTOR_SET_CACHE_V11716", "1");',
        '            Set("SHARPEMU_DESCRIPTOR_SET_CACHE_MAX_SETS_V11716", "4096");',
        '            Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY", "1");',
        '            Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MAX_ENTRIES", "1536");',
        '            Set("SHARPEMU_SHADER_GLOBAL_RESIDENCY_MB", "512");',
        '            Set("SHARPEMU_VK_HOST_BUFFER_CACHE_MB", "256");',
        '            Set("SHARPEMU_VK_DEVICE_BUFFER_CACHE_MB", "1024");',
        '            Set("SHARPEMU_VK_GUEST_BUFFER_CACHE_MB", "512");',
        '            Set("SHARPEMU_VK_SAMPLED_GUEST_IMAGE_CACHE_MB", "1024");',
        '            Set("SHARPEMU_VK_STANDALONE_TEXTURE_CACHE_MB", "4096");',
        '            Set("SHARPEMU_VK_DEVICE_LOCAL_GLOBALS", "1");',
        '            Set("SHARPEMU_REBAR_GLOBAL_DIRECT_V1190", "1");',
        '            Set("SHARPEMU_RUNTIME_SCALAR_DIRECT_V7633", "1");',
        '            Set("SHARPEMU_DS_SAFE_MEMCOPY_V763151", "1");',
        '',
        '            // Never fabricate startup progress with host auto-boot.',
        '            Set("SHARPEMU_BINK_AUTO_BOOT", "0");',
        '        }',
        '',
        '        Console.Error.WriteLine(',
        '            "[V76.3.21.3][GUEST_PROGRESS_RECOVERY] " +',
        '            $"mode={(disableV763213 ? "V21.2/V21.1-baseline" : "conservative-progress")} " +',
        '            "work_per_render=1024 producer_query=256/1024 producer_scan=512 " +',
        '            "closure=300ms/8x128/1000us microbatch=32 compute_chain=4 draw_cb=8 " +',
        '            "wait_fullscan=16ms producer_headroom=48 " +',
        '            "dual_queue=preserved async_agc=preserved snapshot_v212=preserved " +',
        '            "residency=preserved bink=natural-request-only auto_boot=off");',
        '        // V76.3.21.3_GUEST_PROGRESS_RECOVERY_PROFILE_END',
        ''
    ) -join $nl

    $beginPos = $t.IndexOf($begin, [StringComparison]::Ordinal)
    if ($beginPos -ge 0) {
        $endPos = $t.IndexOf($end, $beginPos, [StringComparison]::Ordinal)
        if ($endPos -lt 0) { Fail 'V21.3 existing profile end marker ausente' }
        $endPos += $end.Length
        while ($endPos -lt $t.Length -and
               ($t[$endPos] -eq "`r" -or $t[$endPos] -eq "`n")) {
            $endPos++
        }
        $t = $t.Remove($beginPos, $endPos - $beginPos).Insert($beginPos, $block)
    }
    else {
        # Insert AFTER the V21.1 marker statement: V21.3 is authoritative last.
        $needle = '"[V76.3.21.1][MAX_CRITICAL_PATH_MERGE] " +'
        $pos = $t.IndexOf($needle, [StringComparison]::Ordinal)
        if ($pos -lt 0) { Fail 'V21.1 profile marker anchor ausente' }
        $statementEnd = $t.IndexOf(');', $pos, [StringComparison]::Ordinal)
        if ($statementEnd -lt 0) { Fail 'V21.1 marker statement end ausente' }
        $insertPos = $statementEnd + 2
        $t = $t.Insert($insertPos, $nl + $nl + $block)
    }

    Write-Utf8Preserve $CliPath $t $c.HasBom

    $post = [IO.File]::ReadAllText($CliPath)
    foreach ($m in @(
        '[V76.3.21.3][GUEST_PROGRESS_RECOVERY]',
        'Set("SHARPEMU_MAX_GUEST_WORK_PER_RENDER", "1024");',
        'Set("SHARPEMU_FIFO_WATCHED_PRODUCER_SCAN_DEPTH", "512");',
        'Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_AGE_MS", "300");',
        'Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SYNC_SCAN", "512");',
        'Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_MAX_SLICES", "8");',
        'Set("SHARPEMU_PRODUCER_DEPENDENCY_CLOSURE_SLICE_PAUSE_US", "1000");',
        'Set("SHARPEMU_ORDERED_ACTION_MICROBATCH_MAX", "32");',
        'Set("SHARPEMU_COMPUTE_CHAIN_MAX_V763171", "4");',
        'Set("SHARPEMU_DRAW_COMMAND_BUFFER_MAX", "8");',
        'Set("SHARPEMU_WAIT_FULL_SCAN_MIN_MS", "16");',
        'Set("SHARPEMU_PENDING_GUEST_WORK_PRODUCER_ITEMS", "48");',
        'Set("SHARPEMU_DUAL_PHYSICAL_QUEUE", "1");',
        'Set("SHARPEMU_AGC_ASYNC_COMMAND_PROCESSOR", "1");',
        'Set("SHARPEMU_BINK_AUTO_BOOT", "0");'
    )) {
        if (-not $post.Contains($m)) { Fail "post-apply contract ausente: $m" }
    }

    if ($post.Contains('[V76.3.21.3][GUEST_PROGRESS_PERF_MERGE]')) {
        Fail 'marker incorreto do V21.3 anterior ainda presente'
    }

    Push-Location $Repo
    try {
        & dotnet restore $Project -r win-x64 2>&1 |
            Tee-Object -FilePath $restoreLog
        if ($LASTEXITCODE -ne 0) { Fail "restore falhou exit=$LASTEXITCODE" }

        & dotnet build $Project -t:Rebuild -c Debug -r win-x64 --no-restore `
            -p:Optimize=true -p:DebugSymbols=true -p:DebugType=portable -p:TieredPGO=true 2>&1 |
            Tee-Object -FilePath $buildLog
        if ($LASTEXITCODE -ne 0) { Fail "DEV build falhou exit=$LASTEXITCODE" }
    }
    finally { Pop-Location }

    Write-Host (
        "[$Tag] APPLY+DEV BUILD PASSED cli_only=1 " +
        "backup=$backupZip build=$buildLog"
    )
}
catch {
    try { Restore-Source } catch {}
    throw "[$Tag] $($_.Exception.Message) rollback=completed backup=$backupZip"
}
