﻿param()
. (Join-Path $PSScriptRoot 'common.ps1')
Ensure-Repo

$latest = Get-ChildItem -LiteralPath $Patches -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'V76_3_21_3_PRE_SOURCE_*' } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if (-not $latest) { Fail 'nenhum backup V76.3.21.3 encontrado' }
$src = Join-Path $latest.FullName $CliRel
if (-not (Test-Path -LiteralPath $src -PathType Leaf)) {
    Fail "backup CLI ausente: $src"
}
Copy-Item -LiteralPath $src -Destination $CliPath -Force
Write-Host "[$Tag] ROLLBACK COMPLETED source=$($latest.FullName) cli_only=1"
