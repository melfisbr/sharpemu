@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\diagnostic.ps1"
exit /b %errorlevel%
