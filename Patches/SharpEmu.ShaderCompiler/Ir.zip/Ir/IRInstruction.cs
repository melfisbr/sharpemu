namespace SharpEmu.ShaderCompiler.IR;


public sealed class IRInstruction
{

    public IROpcode Opcode { get; }


    public List<IRValue> Operands { get; }


    public IRValue? Result { get; }


    public IRType Type { get; }



    public IRInstruction(
        IROpcode opcode,
        IRType type,
        IRValue? result = null)
    {

        Opcode = opcode;

        Type = type;

        Result = result;

        Operands = new();

    }



    public void AddOperand(IRValue value)
    {
        Operands.Add(value);
    }

}