namespace SharpEmu.ShaderCompiler.IR;


public enum IROpcode
{

    Nop,


    Add,

    Sub,

    Mul,


    Load,

    Store,


    Branch,

    Return

}