namespace SharpEmu.ShaderCompiler.IR;


public sealed class IRValue
{

    public int Id { get; }


    public IRType Type { get; }


    public string Name { get; }



    public IRValue(
        int id,
        IRType type,
        string name)
    {

        Id = id;

        Type = type;

        Name = name;

    }

}