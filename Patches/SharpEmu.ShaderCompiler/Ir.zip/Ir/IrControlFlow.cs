namespace SharpEmu.ShaderCompiler.IR;


public sealed class IrControlFlowGraph
{

    public List<IrBlockRange> Blocks { get; }
        = new();


    public void AddBlock(
        IrBlockRange block)
    {
        Blocks.Add(block);
    }

}



public sealed class IrBlockRange
{

    public int Start { get; }

    public int End { get; }



    public IrBlockRange(
        int start,
        int end)
    {
        Start = start;
        End = end;
    }


    public bool Contains(
        int index)
    {
        return index >= Start &&
               index <= End;
    }

}