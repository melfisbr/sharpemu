@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\capture_raw_truth.ps1" -RepositoryRoot "%CD%"
exit /b %ERRORLEVEL%
