@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run_dragonball.ps1"
