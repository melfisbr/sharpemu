# Controller options + warning fixes

Adiciona uma opção global e por jogo para selecionar:
- Automático (controle + teclado)
- Somente controle
- Somente teclado
- Desativado

O frontend grava a escolha e transmite `SHARPEMU_INPUT_MODE` ao processo do jogo. O backend `scePad` filtra teclado e gamepad conforme o modo.

Também elimina os quatro avisos atuais do build.
