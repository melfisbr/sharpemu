param(
    [Parameter(Mandatory = $false)]
    [string]$RepositoryRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = (Resolve-Path $RepositoryRoot).Path
$stamp = Get-Date -Format "yyyy-MM-dd-HHmmss"
$backup = Join-Path $repo "artifacts\backup-vsad-$stamp"

$files = @(
    "src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.Alu.cs",
    "src\SharpEmu.ShaderCompiler.Metal\Gen5MslTranslator.Alu.cs"
)

Write-Host "Repositorio: $repo"
Write-Host "Pacote:      $packageRoot"
Write-Host ""

New-Item -ItemType Directory -Force -Path $backup | Out-Null

foreach ($relative in $files) {
    $source = Join-Path $packageRoot $relative
    $destination = Join-Path $repo $relative

    if (-not (Test-Path $source)) {
        throw "Arquivo do pacote nao encontrado: $source"
    }

    if (-not (Test-Path $destination)) {
        throw "Arquivo do repositorio nao encontrado: $destination"
    }

    $backupFile = Join-Path $backup $relative
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backupFile) | Out-Null

    Copy-Item -LiteralPath $destination -Destination $backupFile -Force
    Copy-Item -LiteralPath $source -Destination $destination -Force

    Write-Host "Aplicado: $relative"
}

$vulkanSource = Join-Path $repo "src\SharpEmu.ShaderCompiler.Vulkan\Gen5SpirvTranslator.Alu.cs"
$vsadMatch = Select-String -LiteralPath $vulkanSource -SimpleMatch 'case "VSadU32":'

if (-not $vsadMatch) {
    throw "A verificacao do codigo-fonte falhou: case VSadU32 nao foi encontrado."
}

Write-Host ""
Write-Host "VSadU32 confirmado no codigo-fonte na linha $($vsadMatch.LineNumber)."
Write-Host "Backup: $backup"
Write-Host ""

# The previous package compiled only the backend projects. That updates the
# common net10.0 output, but the executable launched by the user loads the
# dependency copy under net10.0\win-x64. Rebuild the CLI project so its runtime
# folder receives the corrected ShaderCompiler assemblies.

Get-Process -Name "SharpEmu" -ErrorAction SilentlyContinue |
    Stop-Process -Force -ErrorAction SilentlyContinue

$cliProject = Join-Path $repo "src\SharpEmu.CLI\SharpEmu.CLI.csproj"
if (-not (Test-Path $cliProject)) {
    throw "Projeto CLI nao encontrado: $cliProject"
}

$runtimeOutput = Join-Path $repo "artifacts\bin\Debug\net10.0\win-x64"

Write-Host "Limpando a saida runtime antiga..."
dotnet clean $cliProject -c Debug -r win-x64
if ($LASTEXITCODE -ne 0) {
    throw "Falha no dotnet clean do CLI."
}

if (Test-Path $runtimeOutput) {
    Remove-Item -LiteralPath $runtimeOutput -Recurse -Force
}

Write-Host ""
Write-Host "Reconstruindo o executavel e todas as dependencias..."
dotnet build $cliProject -c Debug -r win-x64 --no-incremental
if ($LASTEXITCODE -ne 0) {
    throw "Falha no build completo do CLI."
}

$runtimeVulkan = Join-Path $runtimeOutput "SharpEmu.ShaderCompiler.Vulkan.dll"
$runtimeMetal = Join-Path $runtimeOutput "SharpEmu.ShaderCompiler.Metal.dll"
$runtimeExe = Join-Path $runtimeOutput "SharpEmu.exe"
$runtimeManaged = Join-Path $runtimeOutput "SharpEmu.dll"

if (-not (Test-Path $runtimeVulkan)) {
    throw "A DLL Vulkan corrigida nao foi copiada para a pasta runtime: $runtimeVulkan"
}

if (-not (Test-Path $runtimeMetal)) {
    throw "A DLL Metal corrigida nao foi copiada para a pasta runtime: $runtimeMetal"
}

if (-not (Test-Path $runtimeExe) -and -not (Test-Path $runtimeManaged)) {
    throw "O executavel SharpEmu nao foi gerado em: $runtimeOutput"
}

Write-Host ""
Write-Host "Runtime atualizado:"
Get-Item $runtimeVulkan, $runtimeMetal |
    Select-Object FullName, Length, LastWriteTime |
    Format-Table -AutoSize

$testProjects = @(
    "tests\SharpEmu.ShaderCompiler.Tests\SharpEmu.ShaderCompiler.Tests.csproj",
    "tests\SharpEmu.ShaderCompiler.Metal.Tests\SharpEmu.ShaderCompiler.Metal.Tests.csproj"
)

foreach ($testRelative in $testProjects) {
    $testProject = Join-Path $repo $testRelative
    if (Test-Path $testProject) {
        Write-Host "Executando: $testRelative"
        dotnet test $testProject -c Debug --no-restore
        if ($LASTEXITCODE -ne 0) {
            throw "Falha em $testRelative"
        }
    }
}

Write-Host ""
Write-Host "Correcao VSAD aplicada ao runtime usado pelo SharpEmu."
Write-Host "Execute:"
Write-Host "& `"$runtimeExe`" `"F:\JOGOSPS5\PPSA25646-app\eboot.bin`" --log-level=debug --log-file=gpu_after_vsad_fix_v2.txt"
