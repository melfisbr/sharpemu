# SharpEmu VSAD family fix v2

Esta versão corrige o problema de aplicação do pacote anterior.

O pacote anterior compilava apenas os projetos Vulkan e Metal. Isso atualizava:

`artifacts\bin\Debug\net10.0\SharpEmu.ShaderCompiler.Vulkan.dll`

Porém o executável utilizado pelo usuário carrega a cópia localizada em:

`artifacts\bin\Debug\net10.0\win-x64\SharpEmu.ShaderCompiler.Vulkan.dll`

Como o projeto CLI não era reconstruído, o jogo continuava executando a DLL antiga e ainda informava:

`VSadU32: unsupported vector opcode VSadU32`

O script v2:

1. aplica os dois arquivos corrigidos;
2. confirma que `case "VSadU32":` existe no fonte;
3. encerra processos SharpEmu;
4. limpa a saída do CLI;
5. remove a pasta runtime antiga;
6. reconstrói `SharpEmu.CLI` com `--no-incremental`;
7. confirma que as DLLs atualizadas estão em `net10.0\win-x64`;
8. executa os testes do ShaderCompiler.

Execute na raiz do repositório:

```powershell
Set-ExecutionPolicy -Scope Process Bypass

.\SharpEmu-VSad-Family-Fix-v2\apply_and_validate.ps1 `
    -RepositoryRoot $PWD
```
